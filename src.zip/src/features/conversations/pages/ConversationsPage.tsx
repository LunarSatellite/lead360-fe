import { useState } from 'react';
import { MessageSquare, Users, UserCheck, Clock, ArrowLeftRight, X as XIcon, Loader2 } from 'lucide-react';
import { GlassCard, GlassCardHeader, StatusBadge } from '@/shared/components';
import { useActiveSessions, useAwaitingSessions, useMySessions, useMessages, useCloseSession, useReturnToBot } from '../api/conversation.queries';
import { SESSION_STATUS_LABEL, SESSION_STATUS_COLOR, CHANNEL_LABEL, ROUTING_PATH_LABEL, MessageDirection } from '../types/conversation.types';
import type { SessionDto } from '../types/conversation.types';

export function Component() {
  const [tab, setTab] = useState<'active' | 'awaiting' | 'mine'>('active');
  const [selectedId, setSelectedId] = useState<string | null>(null);
  const { data: active, isLoading } = useActiveSessions();
  const { data: awaiting } = useAwaitingSessions();
  const { data: mine } = useMySessions();
  const sessions = tab === 'active' ? active : tab === 'awaiting' ? awaiting : mine;

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-xl font-extrabold text-text-primary tracking-tight">Conversations</h1>
        <p className="text-sm text-text-secondary mt-1">Monitor live sessions and manage agent handoffs</p>
      </div>
      <div className="grid grid-cols-3 gap-4">
        {[
          { key: 'active' as const, label: 'Active', count: active?.length ?? 0, icon: MessageSquare, color: 'text-success' },
          { key: 'awaiting' as const, label: 'Awaiting Agent', count: awaiting?.length ?? 0, icon: Users, color: 'text-warning' },
          { key: 'mine' as const, label: 'My Sessions', count: mine?.length ?? 0, icon: UserCheck, color: 'text-info' },
        ].map(c => (
          <button key={c.key} onClick={() => setTab(c.key)} className={`text-left ${tab === c.key ? 'ring-2 ring-brand rounded-2xl' : ''}`}>
            <GlassCard className="p-5">
              <div className="flex items-center gap-3">
                <c.icon className={`w-5 h-5 ${c.color}`} />
                <div>
                  <div className={`text-2xl font-extrabold ${c.color}`}>{c.count}</div>
                  <div className="text-xs text-text-muted">{c.label}</div>
                </div>
              </div>
            </GlassCard>
          </button>
        ))}
      </div>
      <div className="flex gap-4" style={{ height: 'calc(100vh - 360px)' }}>
        <GlassCard className="w-[380px] flex-shrink-0 flex flex-col">
          <GlassCardHeader title={`${tab === 'active' ? 'Active' : tab === 'awaiting' ? 'Awaiting' : 'My'} Sessions`} icon={<MessageSquare className="w-4 h-4" />} />
          <div className="flex-1 overflow-y-auto divide-y divide-border-subtle">
            {isLoading ? (
              <div className="p-8 text-center text-sm text-text-muted"><Loader2 className="w-4 h-4 animate-spin mx-auto mb-2" />Loading…</div>
            ) : !sessions?.length ? (
              <div className="p-8 text-center text-sm text-text-muted">No sessions</div>
            ) : sessions.map((s: SessionDto) => (
              <button key={s.id} onClick={() => setSelectedId(s.id)}
                className={`w-full px-4 py-3 text-left transition-colors ${selectedId === s.id ? 'bg-brand-soft' : 'hover:bg-glass-1'}`}>
                <div className="flex items-center justify-between mb-1">
                  <span className="text-xs font-bold text-text-primary truncate">{s.customerId}</span>
                  <StatusBadge variant={SESSION_STATUS_COLOR[s.status]}>{SESSION_STATUS_LABEL[s.status]}</StatusBadge>
                </div>
                <div className="flex items-center gap-2 text-2xs text-text-muted">
                  <span>{CHANNEL_LABEL[s.channel] || 'Unknown'}</span>
                  <span>·</span>
                  <span>{s.messageCount} msgs</span>
                  <span>·</span>
                  <span>{s.mode === 1 ? 'Menu' : 'Chat'}</span>
                </div>
                <div className="text-2xs text-text-muted mt-1 flex items-center gap-1">
                  <Clock className="w-3 h-3" />{new Date(s.lastActivityAt).toLocaleTimeString()}
                </div>
              </button>
            ))}
          </div>
        </GlassCard>
        <div className="flex-1 min-w-0">
          {selectedId ? <MessageViewer sessionId={selectedId} /> : (
            <GlassCard className="h-full flex items-center justify-center">
              <div className="text-center"><MessageSquare className="w-10 h-10 mx-auto text-text-muted mb-2" /><p className="text-sm text-text-muted">Select a session</p></div>
            </GlassCard>
          )}
        </div>
      </div>
    </div>
  );
}

function MessageViewer({ sessionId }: { sessionId: string }) {
  const { data: messages, isLoading } = useMessages(sessionId);
  const close = useCloseSession();
  const returnBot = useReturnToBot();
  return (
    <GlassCard className="h-full flex flex-col">
      <div className="px-5 py-3 border-b border-border-subtle flex items-center justify-between">
        <span className="text-sm font-bold text-text-primary">Messages</span>
        <div className="flex gap-1">
          <button onClick={() => returnBot.mutate(sessionId)} className="flex items-center gap-1 px-2 py-1 rounded text-2xs font-bold text-info bg-info-soft hover:brightness-110"><ArrowLeftRight className="w-3 h-3" /> Bot</button>
          <button onClick={() => close.mutate(sessionId)} className="flex items-center gap-1 px-2 py-1 rounded text-2xs font-bold text-danger bg-danger-soft hover:brightness-110"><XIcon className="w-3 h-3" /> Close</button>
        </div>
      </div>
      <div className="flex-1 overflow-y-auto p-4 space-y-3">
        {isLoading ? <div className="text-center"><Loader2 className="w-4 h-4 animate-spin mx-auto" /></div>
        : !messages?.length ? <div className="text-center text-sm text-text-muted">No messages</div>
        : messages.map(m => (
          <div key={m.id} className={`flex ${m.direction === MessageDirection.Inbound ? 'justify-start' : 'justify-end'}`}>
            <div className={`max-w-[75%] px-3 py-2 rounded-xl text-sm ${
              m.direction === MessageDirection.Inbound
                ? 'bg-glass-1 text-text-primary rounded-bl-none'
                : 'bg-brand text-white rounded-br-none'
            }`}>
              {m.content}
              <div className={`text-2xs mt-1 ${m.direction === MessageDirection.Inbound ? 'text-text-muted' : 'text-white/70'}`}>
                {new Date(m.messageTimestamp).toLocaleTimeString()}
                {m.routingPath > 0 && ` · ${ROUTING_PATH_LABEL[m.routingPath] || ''}`}
              </div>
            </div>
          </div>
        ))}
      </div>
    </GlassCard>
  );
}
