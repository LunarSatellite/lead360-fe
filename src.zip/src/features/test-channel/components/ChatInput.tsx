import { useState, useRef, useEffect } from 'react';
import { Send, Loader2 } from 'lucide-react';

interface ChatInputProps {
  onSend: (text: string) => void;
  disabled?: boolean;
  isSending?: boolean;
  placeholder?: string;
}

export function ChatInput({ onSend, disabled, isSending, placeholder = 'Type a message...' }: ChatInputProps) {
  const [text, setText] = useState('');
  const inputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    if (!isSending) inputRef.current?.focus();
  }, [isSending]);

  const handleSend = () => {
    const trimmed = text.trim();
    if (!trimmed || disabled || isSending) return;
    onSend(trimmed);
    setText('');
  };

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSend();
    }
  };

  return (
    <div className="flex items-center gap-2 p-3 border-t border-t-border-subtle">
      <input
        ref={inputRef}
        value={text}
        onChange={(e) => setText(e.target.value)}
        onKeyDown={handleKeyDown}
        placeholder={placeholder}
        disabled={disabled || isSending}
        className="flex-1 px-4 py-2.5 rounded-lg bg-glass-2 border border-border-subtle text-sm text-text-primary
                   placeholder:text-text-muted focus:outline-none focus:border-brand transition-all
                   disabled:opacity-40"
      />
      <button
        onClick={handleSend}
        disabled={!text.trim() || disabled || isSending}
        className="w-10 h-10 rounded-lg bg-gradient-to-br from-brand to-brand-dark flex items-center justify-center
                   text-text-primary hover:brightness-110 disabled:opacity-40 transition-all flex-shrink-0"
      >
        {isSending ? (
          <Loader2 className="w-4 h-4 animate-spin" />
        ) : (
          <Send className="w-4 h-4" strokeWidth={1.8} />
        )}
      </button>
    </div>
  );
}
