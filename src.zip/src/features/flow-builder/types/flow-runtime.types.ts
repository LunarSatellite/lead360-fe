// ═══════════════════════════════════════════════════════════════
// Flow Runtime — Types (matches backend FlowRuntimeController)
// ═══════════════════════════════════════════════════════════════

export const FlowRuntimeStatus = {
  Response: 1,
  CollectingParams: 2,
  Greeting: 3,
  AgentHandoff: 4,
  NoActiveFlow: 5,
  Error: 6,
} as const;
export type FlowRuntimeStatusValue = (typeof FlowRuntimeStatus)[keyof typeof FlowRuntimeStatus];

export interface FlowMessageRequest {
  SessionId: string;
  Message: string;
}

export interface FlowMenuItemDto {
  label: string;
  value: string;
  icon?: string;
  intentId?: string;
  hasSubMenu: boolean;
}

export interface FlowApiCallResult {
  success: boolean;
  statusCode: number;
  formattedResponse?: string;
  error?: string;
  responseTimeMs: number;
}

export interface FlowRuntimeResult {
  status: FlowRuntimeStatusValue;
  response: string;
  menuItems?: FlowMenuItemDto[];
  currentNodeKey?: string;
  nodeType?: string;
  intentName?: string;
  intentId?: string;
  intentConfidence: number;
  slotPrompt?: string;
  apiCall?: FlowApiCallResult;
  flowPath: string[];
  totalTimeMs: number;
}
