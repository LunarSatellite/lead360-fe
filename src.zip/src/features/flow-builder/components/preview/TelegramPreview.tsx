interface Message {
  role: 'user' | 'bot';
  text: string;
  buttons?: { label: string; value: string }[];
}

interface TelegramPreviewProps {
  messages: Message[];
  onButtonClick: (value: string) => void;
}

export function TelegramPreview({ messages, onButtonClick }: TelegramPreviewProps) {
  return (
    <div className="flex flex-col h-full">
      {/* Header */}
      <div className="flex items-center gap-2 px-3 py-2 bg-[#517DA2] text-white">
        <div className="w-8 h-8 rounded-full bg-[#65B9F4] flex items-center justify-center text-xs font-bold">🤖</div>
        <div className="flex-1 min-w-0">
          <div className="text-xs font-semibold truncate">OmniFlow Bot</div>
          <div className="text-[10px] opacity-70">bot</div>
        </div>
      </div>

      {/* Messages */}
      <div className="flex-1 overflow-auto p-2 space-y-1.5 bg-[#17212B]">
        {messages.length === 0 && (
          <div className="text-center py-6 text-[10px] text-[#6C7883]">Send a message to start</div>
        )}
        {messages.map((m, i) => (
          <div key={i} className={`flex ${m.role === 'user' ? 'justify-end' : 'justify-start'}`}>
            <div className="max-w-[85%]">
              <div
                className="px-2.5 py-1.5 text-[11px] leading-relaxed whitespace-pre-wrap rounded-lg"
                style={
                  m.role === 'user'
                    ? { background: '#2B5278', color: '#fff' }
                    : { background: '#182533', color: '#fff' }
                }
              >
                {m.text}
              </div>
              {m.buttons && m.buttons.length > 0 && (
                <div className="mt-1 grid grid-cols-2 gap-0.5">
                  {m.buttons.map((b, j) => (
                    <button
                      key={j}
                      onClick={() => onButtonClick(b.value)}
                      className="py-1 px-2 rounded text-[10px] font-medium text-[#6AB3F3] bg-[#182533] border border-[#2B5278] hover:bg-[#2B5278] transition-colors text-center truncate"
                    >
                      {b.label}
                    </button>
                  ))}
                </div>
              )}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
