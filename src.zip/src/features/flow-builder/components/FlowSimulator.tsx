import { useState, useRef, useEffect } from 'react';
import { Send, Loader2, RotateCcw } from 'lucide-react';
import { useFlowRuntimeMessage, useFlowRuntimeReset } from '../api/flow.queries';
import { FlowRuntimeStatus, type FlowRuntimeResult, type FlowMenuItemDto } from '../types/flow-runtime.types';

interface SimMsg {
  role: 'user' | 'bot';
  text: string;
  buttons?: FlowMenuItemDto[];
  debug?: FlowRuntimeResult;
}

export function FlowSimulator() {
  const [msgs, setMsgs] = useState<SimMsg[]>([]);
  const [input, setInput] = useState('');
  const [sessionId] = useState(() => crypto.randomUUID());
  const [lastDebug, setLastDebug] = useState<FlowRuntimeResult | null>(null);
  const [isCollectingParam, setIsCollectingParam] = useState(false);
  const [isHandedOff, setIsHandedOff] = useState(false);
  const chatEndRef = useRef<HTMLDivElement>(null);
  const flowMessage = useFlowRuntimeMessage();
  const flowReset = useFlowRuntimeReset();

  useEffect(() => {
    chatEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [msgs.length]);

  const handleFlowResponse = (result: FlowRuntimeResult) => {
    setLastDebug(result);
    setIsCollectingParam(false);

    switch (result.status) {
      case FlowRuntimeStatus.Response:
        setMsgs(p => [...p, {
          role: 'bot', text: result.response,
          buttons: result.menuItems?.length ? result.menuItems : undefined,
          debug: result,
        }]);
        break;

      case FlowRuntimeStatus.CollectingParams:
        setMsgs(p => [...p, { role: 'bot', text: result.response, debug: result }]);
        setIsCollectingParam(true);
        break;

      case FlowRuntimeStatus.Greeting:
        setMsgs(p => [...p, {
          role: 'bot', text: result.response,
          buttons: result.menuItems?.length ? result.menuItems : undefined,
          debug: result,
        }]);
        break;

      case FlowRuntimeStatus.AgentHandoff:
        setMsgs(p => [...p, { role: 'bot', text: result.response, debug: result }]);
        setIsHandedOff(true);
        break;

      case FlowRuntimeStatus.NoActiveFlow:
        setMsgs(p => [
          ...p,
          { role: 'bot', text: result.response, debug: result },
          { role: 'bot', text: '⚠️ Please configure and activate a flow in the Flow Builder first.' },
        ]);
        break;

      case FlowRuntimeStatus.Error:
        setMsgs(p => [...p, {
          role: 'bot', text: result.response || '❌ An error occurred.',
          buttons: result.menuItems?.length ? result.menuItems : undefined,
          debug: result,
        }]);
        break;

      default:
        setMsgs(p => [...p, { role: 'bot', text: result.response || 'Unknown response', debug: result }]);
    }
  };

  const sendMessage = (text: string) => {
    if (!text.trim() || flowMessage.isPending || isHandedOff) return;
    const msg = text.trim();
    setMsgs(p => [...p, { role: 'user', text: msg }]);
    setInput('');

    flowMessage.mutate(
      { SessionId: sessionId, Message: msg },
      {
        onSuccess: handleFlowResponse,
        onError: () => setMsgs(p => [...p, { role: 'bot', text: '❌ Connection failed.' }]),
      },
    );
  };

  const handleMenuClick = (item: FlowMenuItemDto) => {
    setMsgs(p => [...p, { role: 'user', text: item.label }]);
    flowMessage.mutate(
      { SessionId: sessionId, Message: item.value },
      {
        onSuccess: handleFlowResponse,
        onError: () => setMsgs(p => [...p, { role: 'bot', text: '❌ Connection failed.' }]),
      },
    );
  };

  const handleReset = () => {
    flowReset.mutate(sessionId);
    setMsgs([]);
    setLastDebug(null);
    setIsCollectingParam(false);
    setIsHandedOff(false);
  };

  return (
    <div className="flex flex-col h-full">
      {/* Chat area */}
      <div className="flex-1 flex flex-col bg-bg-shell rounded-xl mx-3 mt-3 overflow-hidden border border-border-subtle">
        <div
          className="px-3 py-2.5 flex items-center gap-2 text-white"
          style={{ background: 'linear-gradient(135deg,#059669,#10B981)' }}
        >
          <div className="w-7 h-7 bg-[rgba(255,255,255,.2)] rounded-full flex items-center justify-center text-xs">🤖</div>
          <h4 className="text-2xs font-semibold flex-1">OmniFlow Bot</h4>
          <button onClick={handleReset} className="p-1 rounded-md hover:bg-[rgba(255,255,255,.2)]" title="Reset session">
            <RotateCcw className="w-3 h-3" />
          </button>
        </div>

        <div className="flex-1 overflow-auto p-3 min-h-[180px]">
          {msgs.length === 0 && (
            <div className="text-2xs text-text-muted text-center py-8">
              Send a message to test the bot engine
            </div>
          )}
          {msgs.map((m, i) => (
            <div key={i} className={`mb-2 ${m.role === 'user' ? 'text-right' : ''}`}>
              <div
                className="inline-block max-w-[90%] px-3 py-2 text-2xs leading-relaxed whitespace-pre-wrap"
                style={{
                  borderRadius: 10,
                  ...(m.role === 'user'
                    ? { background: 'linear-gradient(135deg,#059669,#10B981)', color: '#fff', borderBottomRightRadius: 3 }
                    : { background: '#0D1410', color: '#E8F0EC', borderBottomLeftRadius: 3, border: '1px solid #1E2E26' }),
                }}
              >
                {m.text}
              </div>
              {/* Menu buttons */}
              {m.buttons && m.buttons.length > 0 && m.role === 'bot' && (
                <div className="mt-1 space-y-0.5" style={{ maxWidth: '90%' }}>
                  {m.buttons.map((b, j) => (
                    <button key={j} onClick={() => handleMenuClick(b)}
                      className="block w-full py-1.5 px-2 rounded-md bg-brand-soft border border-brand/20 text-[10px] font-medium text-brand hover:bg-[rgba(0,217,126,0.12)] transition-colors text-left">
                      {b.icon && <span className="mr-1">{b.icon}</span>}
                      {b.label}
                    </button>
                  ))}
                </div>
              )}
            </div>
          ))}
          {flowMessage.isPending && (
            <div className="mb-2">
              <div className="inline-block px-3 py-2 text-2xs rounded-[10px] bg-bg-card border border-border-subtle text-text-secondary">
                <Loader2 className="w-3 h-3 animate-spin text-brand inline mr-1" />
                Processing...
              </div>
            </div>
          )}
          <div ref={chatEndRef} />
        </div>

        {/* Input */}
        <div className="p-2.5 border-t border-border-subtle bg-bg-card flex gap-1.5">
          {isHandedOff ? (
            <div className="flex-1 px-2.5 py-2 text-2xs text-text-muted italic">
              Handed off to agent. <button onClick={handleReset} className="text-brand font-semibold underline">Reset</button>
            </div>
          ) : (
            <>
              <input
                value={input}
                onChange={(e) => setInput(e.target.value)}
                onKeyDown={(e) => e.key === 'Enter' && sendMessage(input)}
                placeholder={isCollectingParam ? 'Enter the requested value...' : 'Type a message...'}
                className="flex-1 px-2.5 py-2 border border-border-subtle rounded-lg text-2xs outline-none focus:border-brand bg-bg-shell text-text-primary placeholder:text-text-muted"
              />
              <button
                onClick={() => sendMessage(input)}
                disabled={!input.trim() || flowMessage.isPending}
                className="px-3 py-2 rounded-lg text-2xs font-semibold text-white disabled:opacity-40"
                style={{ background: 'linear-gradient(135deg,#059669,#10B981)' }}
              >
                <Send className="w-3 h-3" />
              </button>
            </>
          )}
        </div>
      </div>

      {/* Debug panel */}
      <div className="mx-3 mb-3 mt-2 p-2.5 rounded-lg bg-bg-card border border-border-subtle">
        <h5 className="text-2xs text-brand mb-1.5 font-bold">🔍 Debug</h5>
        <div className="space-y-0.5 text-2xs">
          <Row label="Status" value={lastDebug ? statusLabel(lastDebug.status) : '-'} />
          <Row label="Intent" value={lastDebug?.intentName || '-'} />
          <Row label="Confidence" value={lastDebug ? `${(lastDebug.intentConfidence * 100).toFixed(0)}%` : '-'} />
          <Row label="Node" value={lastDebug?.currentNodeKey || '-'} />
          <Row label="Type" value={lastDebug?.nodeType || '-'} />
          <Row label="Total" value={lastDebug ? `${lastDebug.totalTimeMs}ms` : '-'} />
          <Row label="Path" value={lastDebug?.flowPath?.join(' → ') || '-'} />
          {lastDebug?.apiCall && (
            <Row label="API" value={`${lastDebug.apiCall.statusCode} (${lastDebug.apiCall.responseTimeMs}ms) ${lastDebug.apiCall.success ? '✅' : '❌'}`} />
          )}
        </div>
      </div>
    </div>
  );
}

function Row({ label, value }: { label: string; value: string }) {
  return (
    <div className="flex justify-between gap-2">
      <span className="text-text-secondary flex-shrink-0">{label}</span>
      <span className="font-medium truncate text-right text-text-primary">{value}</span>
    </div>
  );
}

function statusLabel(status: number): string {
  switch (status) {
    case 1: return 'Response';
    case 2: return 'Collecting Params';
    case 3: return 'Greeting';
    case 4: return 'Agent Handoff';
    case 5: return 'No Active Flow';
    case 6: return 'Error';
    default: return `Unknown (${status})`;
  }
}