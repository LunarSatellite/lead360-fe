/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{ts,tsx}'],
  theme: {
    extend: {
      colors: {
        bg: {
          DEFAULT: '#0A0F0D',
          shell: '#0D1410',
          card: '#111916',
          elevated: '#162019',
          input: '#0D1410',
        },
        glass: {
          1: '#182420',
          2: '#1E2E26',
          3: '#253D32',
        },
        border: {
          subtle: '#1E2E26',
          medium: '#253D32',
          glow: 'rgba(0,255,136,0.15)',
          success: 'rgba(16,185,129,0.15)',
        },
        text: {
          primary: '#FFD84D',
          secondary: '#BFA200',
          muted: '#665C1A',
        },
        brand: {
          DEFAULT: '#00D97E',
          light: '#00FF94',
          dark: '#00B368',
          soft: 'rgba(0,217,126,0.08)',
        },
        success: {
          DEFAULT: '#10B981',
          light: '#34D399',
          soft: 'rgba(16,185,129,0.1)',
        },
        info: {
          DEFAULT: '#3B82F6',
          soft: 'rgba(59,130,246,0.1)',
        },
        danger: {
          DEFAULT: '#F43F5E',
          soft: 'rgba(244,63,94,0.1)',
        },
        warning: {
          DEFAULT: '#F59E0B',
          soft: 'rgba(245,158,11,0.1)',
        },
        sidebar: {
          DEFAULT: '#0A0F0D',
          light: '#111916',
        },
      },
      fontFamily: {
        sans: ['Inter', 'system-ui', '-apple-system', 'sans-serif'],
        mono: ['JetBrains Mono', 'Fira Code', 'monospace'],
      },
      borderRadius: {
        frame: '16px',
        card: '12px',
        sm: '8px',
        xs: '5px',
      },
      fontSize: {
        '2xs': ['11px', { lineHeight: '1.4' }],
        xs: ['12px', { lineHeight: '1.5' }],
        sm: ['14px', { lineHeight: '1.5' }],
        base: ['15px', { lineHeight: '1.6' }],
        lg: ['17px', { lineHeight: '1.5' }],
        xl: ['20px', { lineHeight: '1.4' }],
        '2xl': ['24px', { lineHeight: '1.3' }],
        '3xl': ['30px', { lineHeight: '1.2' }],
        '4xl': ['36px', { lineHeight: '1.1' }],
        '5xl': ['44px', { lineHeight: '1.1' }],
        '6xl': ['54px', { lineHeight: '1.05' }],
      },
      borderWidth: {
        thin: '0.5px',
      },
    },
  },
  plugins: [],
};
