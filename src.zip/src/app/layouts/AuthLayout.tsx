import { Outlet, useLocation } from 'react-router-dom';
import { Zap, TrendingUp, Clock, Shield, Link2, GitBranch, BarChart3 } from 'lucide-react';

export function AuthLayout() {
  const location = useLocation();
  const isRegister = location.pathname.includes('register');

  return (
    <div className="min-h-screen bg-bg flex relative overflow-hidden">
      {/* Background effects */}
      <div
        className="absolute top-[-200px] right-[-100px] w-[600px] h-[600px] rounded-full pointer-events-none opacity-40"
        style={{ background: 'radial-gradient(circle, rgba(0,217,126,0.04), transparent 70%)' }}
      />
      <div
        className="absolute bottom-[-100px] left-[-150px] w-[400px] h-[400px] rounded-full pointer-events-none opacity-30"
        style={{ background: 'radial-gradient(circle, rgba(0,150,232,0.03), transparent 70%)' }}
      />

      {/* Left – Form Panel */}
      <div
        className={`w-full ${isRegister ? 'lg:w-1/2' : 'lg:w-1/2'} flex flex-col ${isRegister ? 'justify-start overflow-y-auto' : 'justify-center'} px-8 sm:px-16 lg:px-20 py-12 relative z-10`}
      >
        {/* Logo */}
        <div className="flex items-center gap-3 mb-12">
          <div className="w-11 h-11 rounded-xl bg-brand flex items-center justify-center">
            <Zap className="w-6 h-6 text-bg" strokeWidth={2.5} />
          </div>
          <div>
            <span className="text-xl font-extrabold text-text-primary tracking-tight">OmniFlow</span>
            <p className="text-2xs text-text-muted">AI chatbot builder</p>
          </div>
        </div>

        <div className={isRegister ? 'max-w-lg' : 'max-w-md'}>
          <Outlet />
        </div>
      </div>

      {/* Right – Marketing Panel */}
      <div className="hidden lg:flex lg:w-1/2 bg-bg-card border-l border-border-subtle flex-col justify-center px-16 xl:px-20 relative">
        {/* Decorative grid */}
        <div className="absolute inset-0 opacity-30 pointer-events-none overflow-hidden">
          <svg width="100%" height="100%">
            <defs>
              <pattern id="auth-grid" width="50" height="50" patternUnits="userSpaceOnUse">
                <path d="M 50 0 L 0 0 0 50" fill="none" stroke="rgba(0,217,126,0.03)" strokeWidth="0.5" />
              </pattern>
            </defs>
            <rect width="100%" height="100%" fill="url(#auth-grid)" />
          </svg>
        </div>

        <div className="relative z-10">
          {isRegister ? (
            /* ── Register: show onboarding preview ── */
            <>
              <p className="text-2xs font-bold uppercase tracking-[3px] text-brand mb-4">
                Get started in minutes
              </p>
              <h2 className="text-3xl font-extrabold text-text-primary leading-tight mb-5">
                From signup to live chatbot in 5 steps
              </h2>
              <p className="text-base text-text-secondary mb-10 max-w-md">
                After registration, our guided setup walks you through connecting your API, defining intents,
                and going live.
              </p>

              <div className="space-y-3 mb-10">
                {[
                  { icon: Link2, num: '01', title: 'Connect your API', desc: 'Upload your OpenAPI spec' },
                  {
                    icon: TrendingUp,
                    num: '02',
                    title: 'Define intents',
                    desc: 'AI suggests what your bot handles',
                  },
                  {
                    icon: GitBranch,
                    num: '03',
                    title: 'Design flows',
                    desc: 'Plain language → conversation tree',
                  },
                  {
                    icon: Shield,
                    num: '04',
                    title: 'Pick channels',
                    desc: 'WhatsApp, Instagram, Facebook, Email, Voice, SMS',
                  },
                  { icon: BarChart3, num: '05', title: 'Go live', desc: 'Flip the switch and monitor' },
                ].map((step) => (
                  <div
                    key={step.num}
                    className="flex items-center gap-4 p-3.5 rounded-xl border border-border-subtle bg-bg-elevated/40 group hover:border-border-glow hover:bg-brand-soft/30 transition-all"
                  >
                    <div className="w-10 h-10 rounded-lg border border-border-subtle bg-bg flex items-center justify-center shrink-0 text-xs font-extrabold text-text-muted group-hover:border-brand group-hover:text-brand group-hover:bg-brand-soft transition-all">
                      {step.num}
                    </div>
                    <div className="flex-1 min-w-0">
                      <p className="text-sm font-bold text-text-primary">{step.title}</p>
                      <p className="text-xs text-text-muted">{step.desc}</p>
                    </div>
                    <step.icon
                      className="w-4 h-4 text-text-muted group-hover:text-brand transition-colors shrink-0"
                      strokeWidth={1.5}
                    />
                  </div>
                ))}
              </div>

              <div className="flex items-center gap-3">
                <div className="flex -space-x-2.5">
                  {['#3B82F6', '#F59E0B', '#8B5CF6'].map((c, i) => (
                    <div
                      key={i}
                      className="w-8 h-8 rounded-full border-2 border-bg-card flex items-center justify-center text-2xs font-bold text-white"
                      style={{ background: c }}
                    >
                      {['AK', 'SR', 'JP'][i]}
                    </div>
                  ))}
                </div>
                <span className="text-xs text-text-muted">
                  <span className="text-brand font-bold">50+</span> teams already building
                </span>
              </div>
            </>
          ) : (
            /* ── Login: original marketing panel ── */
            <>
              <p className="text-2xs font-bold uppercase tracking-[3px] text-brand mb-4">Trusted by teams</p>
              <h2 className="text-4xl font-extrabold text-text-primary leading-tight mb-5">
                Build AI chatbots for any channel, any business
              </h2>
              <p className="text-base text-text-secondary mb-10 max-w-md">
                Connect your API once. Deploy intelligent conversations across WhatsApp, Instagram, Facebook,
                Email, Voice, SMS, and more.
              </p>

              <div className="space-y-4 mb-10">
                {[
                  {
                    icon: TrendingUp,
                    title: '94% AI resolution rate',
                    desc: 'Fewer escalations, happier customers',
                  },
                  { icon: Clock, title: 'Easy setup', desc: 'Upload your API spec and go live' },
                  { icon: Shield, title: 'Enterprise grade', desc: 'Multi-tenant, compliant, scalable' },
                ].map((item) => (
                  <div
                    key={item.title}
                    className="flex items-center gap-4 p-4 rounded-xl border border-border-subtle bg-bg-elevated/40"
                  >
                    <div className="w-10 h-10 rounded-lg border border-border-glow bg-brand-soft flex items-center justify-center shrink-0">
                      <item.icon className="w-5 h-5 text-brand" />
                    </div>
                    <div>
                      <p className="text-sm font-bold text-text-primary">{item.title}</p>
                      <p className="text-xs text-text-muted">{item.desc}</p>
                    </div>
                  </div>
                ))}
              </div>

              {/* Social proof */}
              <div className="flex items-center gap-3">
                <div className="flex -space-x-2.5">
                  {['#3B82F6', '#F59E0B', '#8B5CF6'].map((c, i) => (
                    <div
                      key={i}
                      className="w-8 h-8 rounded-full border-2 border-bg-card flex items-center justify-center text-2xs font-bold text-white"
                      style={{ background: c }}
                    >
                      {['AK', 'SR', 'JP'][i]}
                    </div>
                  ))}
                </div>
                <span className="text-xs text-text-muted">
                  <span className="inline-flex items-center justify-center w-7 h-7 rounded-full border border-border-subtle text-2xs text-text-muted font-medium">
                    +48
                  </span>{' '}
                  teams already building
                </span>
              </div>
            </>
          )}
        </div>
      </div>
    </div>
  );
}
