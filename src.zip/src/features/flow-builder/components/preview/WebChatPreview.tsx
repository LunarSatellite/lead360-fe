interface Message {
  role: 'user' | 'bot';
  text: string;
  buttons?: { label: string; value: string }[];
}

interface WebChatPreviewProps {
  messages: Message[];
  onButtonClick: (value: string) => void;
}

export function WebChatPreview({ messages, onButtonClick }: WebChatPreviewProps) {
  return (
    <div className="flex flex-col h-full">
      {/* Header */}
      <div className="flex items-center gap-2 px-3 py-2 bg-brand text-white">
        <div className="w-8 h-8 rounded-full bg-white/20 flex items-center justify-center text-xs">🤖</div>
        <div className="flex-1 min-w-0">
          <div className="text-xs font-semibold truncate">OmniFlow Support</div>
          <div className="text-[10px] opacity-70 flex items-center gap-1">
            <span className="w-1.5 h-1.5 rounded-full bg-[#10B981]" />
            Online
          </div>
        </div>
      </div>

      {/* Messages */}
      <div className="flex-1 overflow-auto p-2 space-y-2 bg-bg-shell">
        {messages.length === 0 && (
          <div className="text-center py-6 text-[10px] text-text-muted">Start a conversation</div>
        )}
        {messages.map((m, i) => (
          <div key={i} className={`flex ${m.role === 'user' ? 'justify-end' : 'justify-start'} gap-1.5`}>
            {m.role === 'bot' && (
              <div className="w-6 h-6 rounded-full bg-brand flex items-center justify-center text-[10px] text-white flex-shrink-0 mt-0.5">
                🤖
              </div>
            )}
            <div className="max-w-[80%]">
              <div
                className="px-3 py-2 text-[11px] leading-relaxed whitespace-pre-wrap rounded-2xl"
                style={
                  m.role === 'user'
                    ? { background: '#059669', color: '#fff', borderBottomRightRadius: 4 }
                    : {
                        background: '#0D1410',
                        color: '#E8F0EC',
                        border: '1px solid #1E2E26',
                        borderBottomLeftRadius: 4,
                      }
                }
              >
                {m.text}
              </div>
              {m.buttons && m.buttons.length > 0 && (
                <div className="mt-1.5 flex flex-wrap gap-1">
                  {m.buttons.map((b, j) => (
                    <button
                      key={j}
                      onClick={() => onButtonClick(b.value)}
                      className="px-3 py-1.5 rounded-full text-[10px] font-medium text-brand bg-bg-card border border-brand/30 hover:bg-brand-soft transition-colors"
                    >
                      {b.label}
                    </button>
                  ))}
                </div>
              )}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
