import { memo } from 'react';
import { Handle, Position } from '@xyflow/react';
import type { FlowNodeData } from '../../types/flow.types';
function Inner({ data }: { data: FlowNodeData }) {
  const rules = (data.config as { rules?: string[] })?.rules || [];
  return (
    <div className="w-[180px] bg-bg-card rounded-xl border-2 border-amber-700 hover:brightness-110 transition-shadow">
      <Handle
        type="target"
        position={Position.Top}
        className="!w-3 !h-3 !bg-amber-500 !border-2 !border-bg-card"
      />
      <div className="flex items-center gap-2 px-3 py-2.5 border-b border-amber-800">
        <div className="w-6 h-6 rounded-md bg-amber-950 flex items-center justify-center text-xs">🔀</div>
        <span className="text-xs font-semibold text-text-primary truncate flex-1">{data.label}</span>
      </div>
      <div className="px-3 py-1.5">
        {rules.length > 0 ? (
          rules.map((r, i) => (
            <div key={i} className="text-[10px] text-amber-400 py-0.5">
              → {r}
            </div>
          ))
        ) : (
          <span className="px-1.5 py-0.5 rounded bg-amber-950 text-amber-400 text-[10px] font-medium">
            Branch
          </span>
        )}
      </div>
      <Handle
        type="source"
        position={Position.Bottom}
        className="!w-3 !h-3 !bg-amber-500 !border-2 !border-bg-card"
      />
    </div>
  );
}
export const ConditionNode = memo(Inner);
