import { memo } from 'react';
import { Handle, Position } from '@xyflow/react';
import type { FlowNodeData } from '../../types/flow.types';
function Inner({ data }: { data: FlowNodeData }) {
  return (
    <div className="w-[180px] bg-bg-card rounded-xl border-2 border-blue-700 hover:brightness-110 transition-shadow">
      <div className="flex items-center gap-2 px-3 py-2.5 border-b border-blue-800">
        <div className="w-6 h-6 rounded-md bg-blue-950 flex items-center justify-center text-xs">⚡</div>
        <span className="text-xs font-semibold text-text-primary truncate flex-1">{data.label}</span>
      </div>
      <div className="px-3 py-2">
        <span className="px-1.5 py-0.5 rounded bg-blue-950 text-blue-400 text-[10px] font-medium">
          Entry Point
        </span>
      </div>
      <Handle
        type="source"
        position={Position.Bottom}
        className="!w-3 !h-3 !bg-blue-500 !border-2 !border-bg-card"
      />
    </div>
  );
}
export const TriggerNode = memo(Inner);
