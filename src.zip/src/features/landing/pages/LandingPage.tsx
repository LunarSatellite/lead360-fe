import { useState, useEffect, useRef, useCallback } from 'react';
import { Link } from 'react-router-dom';
import { Zap, ArrowRight, Check, Link2, Sun, GitBranch, MessageSquare, Users, BarChart3 } from 'lucide-react';

/* ═══════════════════════════════════════════════════════
   Particle canvas background
   ═══════════════════════════════════════════════════════ */
function ParticleCanvas() {
  const ref = useRef<HTMLCanvasElement>(null);

  useEffect(() => {
    const c = ref.current;
    if (!c) return;
    const ctx = c.getContext('2d');
    if (!ctx) return;

    let raf: number;
    const pts: { x: number; y: number; vx: number; vy: number; r: number }[] = [];

    function resize() {
      c!.width = c!.offsetWidth;
      c!.height = c!.offsetHeight;
    }
    resize();
    window.addEventListener('resize', resize);

    for (let i = 0; i < 60; i++) {
      pts.push({
        x: Math.random() * c.width,
        y: Math.random() * c.height,
        vx: (Math.random() - 0.5) * 0.3,
        vy: (Math.random() - 0.5) * 0.3,
        r: Math.random() * 1.5 + 0.5,
      });
    }

    function draw() {
      ctx!.clearRect(0, 0, c!.width, c!.height);
      for (let i = 0; i < pts.length; i++) {
        const p = pts[i];
        p.x += p.vx;
        p.y += p.vy;
        if (p.x < 0) p.x = c!.width;
        if (p.x > c!.width) p.x = 0;
        if (p.y < 0) p.y = c!.height;
        if (p.y > c!.height) p.y = 0;
        ctx!.beginPath();
        ctx!.arc(p.x, p.y, p.r, 0, Math.PI * 2);
        ctx!.fillStyle = 'rgba(0,255,170,.25)';
        ctx!.fill();
        for (let j = i + 1; j < pts.length; j++) {
          const q = pts[j];
          const dx = p.x - q.x;
          const dy = p.y - q.y;
          const d = Math.sqrt(dx * dx + dy * dy);
          if (d < 120) {
            ctx!.beginPath();
            ctx!.moveTo(p.x, p.y);
            ctx!.lineTo(q.x, q.y);
            ctx!.strokeStyle = `rgba(0,255,170,${0.12 * (1 - d / 120)})`;
            ctx!.lineWidth = 0.5;
            ctx!.stroke();
          }
        }
      }
      raf = requestAnimationFrame(draw);
    }
    draw();

    return () => {
      window.removeEventListener('resize', resize);
      cancelAnimationFrame(raf);
    };
  }, []);

  return (
    <canvas
      ref={ref}
      className="absolute top-0 left-0 w-full pointer-events-none z-[1]"
      style={{ height: 700 }}
    />
  );
}

/* ═══════════════════════════════════════════════════════
   Reusable components
   ═══════════════════════════════════════════════════════ */
function SectionTag({ children }: { children: React.ReactNode }) {
  return <span className="landing-sec-tag">{children}</span>;
}

function CtaButton({ children, to, large }: { children: React.ReactNode; to: string; large?: boolean }) {
  return (
    <Link
      to={to}
      className={`landing-cta ${large ? 'text-[17px] py-[18px] px-[52px]' : 'text-[15px] py-[14px] px-[36px]'}`}
    >
      <span className="landing-beam" />
      {children}
    </Link>
  );
}

function GhostButton({ children, href, to }: { children: React.ReactNode; href?: string; to?: string }) {
  const cls = 'landing-cta2';
  if (to)
    return (
      <Link to={to} className={cls}>
        {children}
      </Link>
    );
  return (
    <a href={href} className={cls}>
      {children}
    </a>
  );
}

/* ═══════════════════════════════════════════════════════
   Channel showcase data
   ═══════════════════════════════════════════════════════ */
const CHANNEL_TABS = [
  { name: 'WhatsApp', icon: '💬', color: '#25D366', type: 'Rich interactive' },
  { name: 'Instagram', icon: '📸', color: '#E4405F', type: 'DM + Stories' },
  { name: 'Facebook', icon: '📘', color: '#1877F2', type: 'Quick replies + Cards' },
  { name: 'Telegram', icon: '✈️', color: '#2AABEE', type: 'Inline keyboards' },
  { name: 'Email', icon: '✉️', color: '#F43F5E', type: 'Templates + Threads' },
  { name: 'Voice', icon: '🎙️', color: '#A78BFA', type: 'IVR + Voice-to-text' },
  { name: 'Web chat', icon: '🌐', color: '#60A5FA', type: 'Embed widget' },
  { name: 'SMS', icon: '📱', color: '#FBBF24', type: 'Text-only' },
];

/* ─── Per-channel native UI screens ─── */
function WhatsAppScreen() {
  return (
    <>
      <div className="ch-bub ch-bub-u ch-mp">Show me your menu</div>
      <div className="ch-bub ch-bub-b ch-mp" style={{ background: '#25D36618' }}>
        Here's what I can help with:
      </div>
      <div
        className="ch-mp"
        style={{ border: '1px solid #25D36630', borderRadius: 12, overflow: 'hidden', marginBottom: 6 }}
      >
        <div
          style={{
            padding: '6px 12px',
            fontSize: 10,
            fontWeight: 700,
            color: '#25D366',
            borderBottom: '1px solid #25D36620',
          }}
        >
          Main menu
        </div>
        {['Browse products', 'Track my order', 'Talk to support'].map((t) => (
          <div
            key={t}
            style={{
              padding: '8px 12px',
              fontSize: 11,
              color: '#8FAEA0',
              display: 'flex',
              justifyContent: 'space-between',
              borderBottom: '1px solid #0A0D0C',
            }}
          >
            <span>{t}</span>
            <span style={{ color: '#25D366', fontSize: 10 }}>&gt;</span>
          </div>
        ))}
      </div>
      <div className="ch-mp" style={{ display: 'flex', gap: 4, marginTop: 2 }}>
        {['Browse', 'Track', 'Help'].map((t) => (
          <span
            key={t}
            style={{
              flex: 1,
              padding: '6px 12px',
              borderRadius: 10,
              fontSize: 10,
              fontWeight: 600,
              textAlign: 'center',
              background: '#25D36620',
              color: '#25D366',
              border: '1px solid #25D36630',
            }}
          >
            {t}
          </span>
        ))}
      </div>
    </>
  );
}

function InstagramScreen() {
  return (
    <>
      <div className="ch-mp" style={{ display: 'flex', gap: 6, marginBottom: 10, overflowX: 'auto' }}>
        {['🛍️', '👟', '👗', '🎒'].map((e, i) => (
          <div
            key={i}
            style={{
              width: 48,
              height: 48,
              borderRadius: '50%',
              flexShrink: 0,
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              fontSize: 16,
              background: i === 0 ? '#E4405F20' : '#E4405F10',
              border: `2px solid ${i === 0 ? '#E4405F' : '#E4405F40'}`,
            }}
          >
            {e}
          </div>
        ))}
      </div>
      <div className="ch-bub ch-bub-u ch-mp">Is this available in blue?</div>
      <div className="ch-bub ch-bub-b ch-mp" style={{ background: '#E4405F18' }}>
        Yes! Here it is:
      </div>
      <div
        className="ch-mp"
        style={{ borderRadius: 12, overflow: 'hidden', background: '#1B2E25', marginBottom: 6 }}
      >
        <div
          style={{
            height: 80,
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            fontSize: 28,
            background: '#E4405F10',
          }}
        >
          👟
        </div>
        <div
          style={{
            padding: '8px 10px',
            display: 'flex',
            justifyContent: 'space-between',
            alignItems: 'center',
          }}
        >
          <span style={{ fontSize: 11, fontWeight: 600 }}>Air Max 90 - Azure Blue</span>
          <span style={{ fontSize: 10, fontWeight: 700, color: '#E4405F' }}>$129</span>
        </div>
      </div>
    </>
  );
}

function FacebookScreen() {
  return (
    <>
      <div className="ch-bub ch-bub-b ch-mp" style={{ background: '#1877F218' }}>
        Welcome! How can I help?
      </div>
      <div className="ch-mp" style={{ display: 'flex', gap: 6, flexWrap: 'wrap', marginBottom: 6 }}>
        {['Track order', 'Browse', 'Support'].map((t) => (
          <span
            key={t}
            style={{
              padding: '6px 12px',
              borderRadius: 20,
              fontSize: 10,
              fontWeight: 600,
              background: '#1877F218',
              color: '#1877F2',
              border: '1px solid #1877F230',
            }}
          >
            {t}
          </span>
        ))}
      </div>
      <div className="ch-bub ch-bub-u ch-mp">Browse</div>
      <div
        className="ch-mp"
        style={{ borderRadius: 12, overflow: 'hidden', border: '1px solid #1877F230', marginBottom: 6 }}
      >
        <div
          style={{
            height: 60,
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            fontSize: 24,
            background: '#1877F210',
          }}
        >
          🎧
        </div>
        <div style={{ padding: '8px 10px' }}>
          <div style={{ fontSize: 11, fontWeight: 700 }}>ProMax Headphones</div>
          <div style={{ fontSize: 9, color: '#4D6E5F' }}>Noise-canceling — $89.99</div>
        </div>
      </div>
    </>
  );
}

function TelegramScreen() {
  return (
    <>
      <div className="ch-bub ch-bub-u ch-mp">What can you do?</div>
      <div className="ch-bub ch-bub-b ch-mp" style={{ background: '#2AABEE18' }}>
        Pick an option:
      </div>
      <div
        className="ch-mp"
        style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 4, marginBottom: 6 }}
      >
        {['📦 Orders', '🔍 Search', '💬 Support', '📋 FAQ'].map((t) => (
          <span
            key={t}
            style={{
              padding: 8,
              borderRadius: 8,
              fontSize: 10,
              fontWeight: 600,
              textAlign: 'center',
              background: '#2AABEE18',
              color: '#2AABEE',
              border: '1px solid #2AABEE30',
            }}
          >
            {t}
          </span>
        ))}
      </div>
      <div className="ch-bub ch-bub-u ch-mp">📦 Orders</div>
      <div className="ch-bub ch-bub-b ch-mp" style={{ background: '#2AABEE18' }}>
        Order #4821 — <strong style={{ color: '#2AABEE' }}>Out for delivery</strong>
      </div>
    </>
  );
}

function EmailScreen() {
  return (
    <>
      <div
        className="ch-mp"
        style={{ borderBottom: '1px solid #132A21', paddingBottom: 10, marginBottom: 10 }}
      >
        <div
          style={{
            display: 'flex',
            justifyContent: 'space-between',
            fontSize: 10,
            color: '#4D6E5F',
            marginBottom: 4,
          }}
        >
          <span>From: bot@yourstore.com</span>
          <span>2 min ago</span>
        </div>
        <div style={{ display: 'flex', fontSize: 10, color: '#4D6E5F', marginBottom: 8 }}>
          To: sarah@email.com
        </div>
        <div style={{ fontSize: 14, fontWeight: 700 }}>Your return has been approved</div>
      </div>
      <div className="ch-mp" style={{ fontSize: 11, color: '#8FAEA0', lineHeight: 1.7, marginBottom: 12 }}>
        Hi Sarah,
        <br />
        <br />
        Great news — your return for Order #7291 has been approved. We've attached a prepaid label.
        <br />
        <br />
        Refund of <strong style={{ color: '#F43F5E' }}>$89.99</strong> will process in 3-5 days.
      </div>
      <div className="ch-mp">
        <span
          style={{
            display: 'inline-block',
            padding: '8px 20px',
            borderRadius: 8,
            fontSize: 11,
            fontWeight: 700,
            background: '#F43F5E20',
            color: '#F43F5E',
            border: '1px solid #F43F5E30',
          }}
        >
          Download shipping label
        </span>
      </div>
    </>
  );
}

function VoiceScreen() {
  return (
    <div
      style={{
        display: 'flex',
        flexDirection: 'column',
        alignItems: 'center',
        justifyContent: 'center',
        flex: 1,
      }}
    >
      <div className="ch-mp ch-voice-circle">🎙️</div>
      <div className="ch-mp" style={{ fontSize: 13, fontWeight: 700, color: '#A78BFA', textAlign: 'center' }}>
        Incoming call
      </div>
      <div
        className="ch-mp"
        style={{ fontSize: 11, color: '#4D6E5F', textAlign: 'center', marginBottom: 16 }}
      >
        AI assistant is handling the call
      </div>
      <div className="ch-mp" style={{ display: 'flex', flexDirection: 'column', gap: 4, width: '100%' }}>
        {[
          { n: '1', t: 'Track your order' },
          { n: '2', t: 'Product information' },
          { n: '3', t: 'Speak to an agent' },
          { n: '0', t: 'Repeat options' },
        ].map((o) => (
          <div
            key={o.n}
            style={{
              display: 'flex',
              alignItems: 'center',
              gap: 10,
              padding: '8px 12px',
              borderRadius: 10,
              background: '#0F1A16',
              border: '1px solid #132A21',
              fontSize: 11,
            }}
          >
            <span
              style={{
                width: 20,
                height: 20,
                borderRadius: 6,
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
                fontSize: 10,
                fontWeight: 800,
                background: '#A78BFA20',
                color: '#A78BFA',
              }}
            >
              {o.n}
            </span>
            <span style={{ color: '#8FAEA0' }}>{o.t}</span>
          </div>
        ))}
      </div>
    </div>
  );
}

function WebChatScreen() {
  return (
    <div className="ch-mp" style={{ border: '1px solid #60A5FA30', borderRadius: 14, overflow: 'hidden' }}>
      <div
        style={{
          padding: '8px 12px',
          background: '#60A5FA10',
          display: 'flex',
          alignItems: 'center',
          gap: 8,
          borderBottom: '1px solid #60A5FA20',
        }}
      >
        <div
          style={{
            width: 28,
            height: 28,
            borderRadius: 8,
            background: '#60A5FA',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            fontSize: 12,
            color: '#050808',
            fontWeight: 800,
          }}
        >
          O
        </div>
        <div>
          <div style={{ fontSize: 11, fontWeight: 700 }}>OmniFlow Bot</div>
          <div style={{ fontSize: 9, color: '#4D6E5F' }}>Online</div>
        </div>
      </div>
      <div style={{ padding: 10 }}>
        <div
          className="ch-bub ch-bub-b"
          style={{ background: '#60A5FA18', maxWidth: '100%', marginBottom: 6 }}
        >
          Hi! I'm your AI assistant. How can I help?
        </div>
        <div className="ch-bub ch-bub-u" style={{ marginBottom: 6 }}>
          I need help with my order
        </div>
        <div
          className="ch-bub ch-bub-b"
          style={{ background: '#60A5FA18', maxWidth: '100%', marginBottom: 6 }}
        >
          Sure! Enter your order number below.
        </div>
        <div style={{ display: 'flex', gap: 6, marginTop: 8 }}>
          <div
            style={{
              flex: 1,
              padding: '6px 10px',
              borderRadius: 8,
              background: '#0A0D0C',
              border: '1px solid #132A21',
              fontSize: 10,
              color: '#4D6E5F',
            }}
          >
            Type order number...
          </div>
          <div
            style={{
              width: 28,
              height: 28,
              borderRadius: 8,
              background: '#60A5FA',
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              fontSize: 12,
              color: '#050808',
            }}
          >
            →
          </div>
        </div>
      </div>
    </div>
  );
}

function SMSScreen() {
  return (
    <>
      <div
        className="ch-mp"
        style={{ fontSize: 11, color: '#4D6E5F', textAlign: 'center', marginBottom: 10 }}
      >
        Text message conversation
      </div>
      {[
        { from: 'bot', text: 'Welcome to ShopBot! Reply with:\nTRACK, BROWSE, or HELP' },
        { from: 'user', text: 'TRACK' },
        { from: 'bot', text: 'Enter your order number:' },
        { from: 'user', text: '4821' },
        { from: 'bot', text: 'Order #4821: Out for delivery.\nETA 3:00 PM.\nReply DETAILS for more.' },
      ].map((m, i) => (
        <div
          key={i}
          className="ch-mp"
          style={{
            padding: '8px 12px',
            borderRadius: 14,
            fontSize: 12,
            lineHeight: 1.5,
            maxWidth: '90%',
            marginBottom: 6,
            whiteSpace: 'pre-line',
            ...(m.from === 'user'
              ? { alignSelf: 'flex-end', background: '#1B2E25', color: '#8FAEA0', borderBottomRightRadius: 4 }
              : {
                  alignSelf: 'flex-start',
                  background: '#FBBF2418',
                  color: '#E6F5ED',
                  borderBottomLeftRadius: 4,
                }),
          }}
        >
          {m.text}
        </div>
      ))}
    </>
  );
}

const SCREENS = [
  WhatsAppScreen,
  InstagramScreen,
  FacebookScreen,
  TelegramScreen,
  EmailScreen,
  VoiceScreen,
  WebChatScreen,
  SMSScreen,
];

/* ─── Channel showcase component ─── */
function ChannelShowcase() {
  const [active, setActive] = useState(0);
  const timerRef = useRef<ReturnType<typeof setInterval>>();

  const goTo = useCallback((n: number) => {
    setActive(n);
    clearInterval(timerRef.current);
    timerRef.current = setInterval(() => setActive((p) => (p + 1) % CHANNEL_TABS.length), 4000);
  }, []);

  useEffect(() => {
    timerRef.current = setInterval(() => setActive((p) => (p + 1) % CHANNEL_TABS.length), 4000);
    return () => clearInterval(timerRef.current);
  }, []);

  const ch = CHANNEL_TABS[active];
  const Screen = SCREENS[active];

  return (
    <section id="channels" className="relative z-10 px-14 py-24 border-t border-[#132A21]">
      <div className="text-center mb-10">
        <SectionTag>Channels</SectionTag>
        <h2 className="text-[44px] font-extrabold tracking-[-2px] leading-[1.05] mt-5 text-text-primary">
          Same bot, <span className="text-brand">native everywhere</span>
        </h2>
      </div>

      {/* Tab navigation */}
      <div className="flex justify-center gap-2 mb-8 flex-wrap max-w-[680px] mx-auto">
        {CHANNEL_TABS.map((c, i) => (
          <button
            key={c.name}
            onClick={() => goTo(i)}
            className={`ch-tab ${active === i ? 'ch-tab-on' : ''}`}
            style={{ '--cc': c.color } as React.CSSProperties}
          >
            <span className="w-[7px] h-[7px] rounded-full shrink-0" style={{ background: c.color }} />
            {c.name}
          </button>
        ))}
      </div>

      {/* Device frame */}
      <div className="ch-device" style={{ '--dc': ch.color } as React.CSSProperties}>
        <div className="ch-device-bar">
          <div className="flex items-center gap-2">
            <span className="w-[10px] h-[10px] rounded-full" style={{ background: ch.color }} />
            <span className="text-xs font-bold" style={{ color: ch.color }}>
              {ch.name}
            </span>
          </div>
          <span className="text-[9px] text-[#4D6E5F] font-medium">{ch.type}</span>
        </div>
        <div className="ch-device-body" key={active}>
          <Screen />
        </div>
      </div>

      <p className="text-center text-[13px] text-[#4D6E5F] mt-6">
        Same bot logic — different native UI per channel. Auto-cycles or click to explore.
      </p>
    </section>
  );
}

/* ═══════════════════════════════════════════════════════
   Data
   ═══════════════════════════════════════════════════════ */
const FEATURES = [
  {
    icon: Link2,
    title: 'API-first integration',
    desc: 'Upload your OpenAPI spec and we auto-detect every capability. No custom code.',
    color: 'rgba(0,255,170,.08)',
    stroke: '#00FFAA',
  },
  {
    icon: Sun,
    title: 'Intent system',
    desc: 'Three ways to define: AI-suggested, bulk import, or manual entry.',
    color: 'rgba(96,165,250,.08)',
    stroke: '#60A5FA',
  },
  {
    icon: GitBranch,
    title: 'Visual flow builder',
    desc: 'Plain language in, conversation tree out. With live channel preview.',
    color: 'rgba(167,139,250,.08)',
    stroke: '#A78BFA',
  },
  {
    icon: MessageSquare,
    title: 'LLM conversations',
    desc: 'Dual chat + menu mode. AI understands natural language and routes actions.',
    color: 'rgba(251,191,36,.08)',
    stroke: '#FBBF24',
  },
  {
    icon: Users,
    title: 'Agent handoff',
    desc: 'Seamless human escalation with full conversation context.',
    color: 'rgba(244,63,94,.08)',
    stroke: '#F43F5E',
  },
  {
    icon: BarChart3,
    title: 'Real-time analytics',
    desc: 'Resolution rates, intent matches, conversation volume across all channels.',
    color: 'rgba(52,211,153,.08)',
    stroke: '#34D399',
  },
];

const STEPS = [
  {
    num: '01',
    title: 'Connect your API',
    desc: 'Upload your OpenAPI spec. We auto-detect every endpoint and build a capability map of your system.',
  },
  {
    num: '02',
    title: 'Define intents',
    desc: 'AI suggests what your bot should handle based on your API. Approve, edit, or add your own.',
  },
  {
    num: '03',
    title: 'Design conversation flows',
    desc: 'Describe in plain English. AI generates the conversation tree with a live preview adapted to your chosen channel.',
  },
  {
    num: '04',
    title: 'Pick your channels',
    desc: 'Each channel adapts automatically — rich cards for WhatsApp, templates for Email, IVR for Voice, simplified text for SMS. One bot, every format.',
  },
  {
    num: '05',
    title: 'Go live',
    desc: 'Flip the switch. Customers start chatting immediately. Monitor everything from the dashboard.',
  },
];

const PLANS = [
  {
    name: 'Starter',
    price: 'Free',
    period: 'forever',
    features: ['1 channel', '100 conversations/mo', '10 intents'],
    cta: 'Get started',
    primary: false,
  },
  {
    name: 'Growth',
    price: '$49',
    period: '/mo',
    features: ['3 channels', '5,000 conversations/mo', 'Unlimited intents', 'AI flow builder'],
    cta: 'Start free trial',
    primary: true,
  },
  {
    name: 'Enterprise',
    price: 'Custom',
    period: 'talk to us',
    features: ['Unlimited channels', 'Unlimited conversations', 'Custom LLM models', 'SLA guarantee'],
    cta: 'Contact sales',
    primary: false,
  },
];

/* ═══════════════════════════════════════════════════════
   Main page
   ═══════════════════════════════════════════════════════ */
export function Component() {
  return (
    <div className="min-h-screen bg-[#050808] text-[#E6F5ED] font-sans overflow-x-hidden relative">
      <ParticleCanvas />

      {/* ─── NAV ─── */}
      <nav className="relative z-10 flex items-center justify-between px-14 py-5">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-brand flex items-center justify-center relative">
            <div className="absolute inset-0 rounded-xl border-2 border-brand landing-pulse-ring" />
            <Zap className="w-[22px] h-[22px] text-[#050808]" strokeWidth={2.5} />
          </div>
          <span className="text-xl font-extrabold tracking-tight text-text-primary">OmniFlow</span>
        </div>
        <div className="hidden md:flex items-center gap-10">
          {['Features', 'How it works', 'Channels', 'Pricing'].map((t) => (
            <a key={t} href={`#${t.toLowerCase().replace(/ /g, '-')}`} className="landing-nav-link">
              {t}
            </a>
          ))}
        </div>
        <div className="flex items-center gap-4">
          <Link
            to="/auth/login"
            className="text-sm font-medium text-[#FFD54A] hover:text-[#00D97E] transition-colors"
          >
            Sign in
          </Link>
          <Link to="/auth/register" className="landing-cta text-[13px] py-[10px] px-[24px]">
            <span className="landing-beam" />
            Get started <ArrowRight className="w-4 h-4" />
          </Link>
        </div>
      </nav>

      {/* ─── HERO ─── */}
      <section className="relative z-10 px-14 pt-24 pb-20 text-center">
        <div className="landing-hero-blob" />
        <div className="landing-orb-ring">
          <div
            className="landing-orbit-dot"
            style={{
              background: '#00FFAA',
              boxShadow: '0 0 12px #00FFAA',
              animation: 'landing-orbit 10s linear infinite',
            }}
          />
          <div
            className="landing-orbit-dot"
            style={{
              width: 6,
              height: 6,
              background: '#60A5FA',
              boxShadow: '0 0 10px #60A5FA',
              animation: 'landing-orbit2 14s linear infinite',
            }}
          />
          <div
            className="landing-orbit-dot"
            style={{
              width: 8,
              height: 8,
              background: '#A78BFA',
              boxShadow: '0 0 10px #A78BFA',
              animation: 'landing-orbit3 8s linear infinite',
            }}
          />
        </div>

        <div className="landing-d1 mb-9">
          <SectionTag>
            <span className="w-1.5 h-1.5 rounded-full bg-brand inline-block landing-pulse-ring" />
            Now in public beta
          </SectionTag>
        </div>

        <h1 className="landing-d2 text-[76px] font-black leading-[0.95] tracking-[-4px] max-w-[800px] mx-auto text-text-primary">
          Build AI chatbots
          <br />
          <span className="landing-shimmer-text">for any channel</span>
        </h1>

        <p className="landing-d3 text-lg text-text-secondary mt-8 max-w-[500px] mx-auto leading-relaxed font-normal">
          Connect your API once. Deploy intelligent conversations across WhatsApp, Email, Voice, SMS, and more
          — zero code required.
        </p>

        <div className="landing-d4 flex justify-center gap-4 mt-11">
          <CtaButton to="/auth/register">
            Start building free <ArrowRight className="w-5 h-5" />
          </CtaButton>
          <GhostButton href="#how-it-works">Watch demo</GhostButton>
        </div>

        {/* Channel pills */}
        {/* <div className="landing-d4 flex justify-center gap-3 mt-12 flex-wrap">
          {CHANNEL_TABS.map((ch) => (
            <div key={ch.name} className="landing-ch-pill">
              <span
                className="w-2 h-2 rounded-full"
                style={{
                  background: ch.color,
                  boxShadow: `0 0 8px ${ch.color}`,
                  animation: 'landing-glow-pulse 2s ease infinite',
                }}
              />
              {ch.name}
            </div>
          ))}
        </div> */}
      </section>

      {/* ─── CHANNEL SHOWCASE ─── */}
      <ChannelShowcase />

      {/* ─── HOW IT WORKS ─── */}
      <section id="how-it-works" className="relative z-10 px-14 py-24 border-t border-[#132A21]">
        <div className="text-center mb-14">
          <SectionTag>How it works</SectionTag>
          <h2 className="text-[44px] font-extrabold tracking-[-2px] leading-[1.05] mt-5 text-text-primary">
            From zero to live
            <br />
            in <span className="text-brand">five steps</span>
          </h2>
        </div>
        <div className="max-w-[640px] mx-auto">
          {STEPS.map((s) => (
            <div key={s.num} className="landing-step-row">
              <div className="landing-step-n">{s.num}</div>
              <div>
                <div className="text-[17px] font-bold mb-1.5 text-text-primary">{s.title}</div>
                <div className="text-sm text-[#8FAEA0] leading-relaxed">{s.desc}</div>
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* ─── FEATURES ─── */}
      <section id="features" className="relative z-10 px-14 py-24 border-t border-[#132A21]">
        <div className="text-center mb-14">
          <SectionTag>Platform</SectionTag>
          <h2 className="text-[44px] font-extrabold tracking-[-2px] leading-[1.05] mt-5 text-text-primary">
            Everything you need
          </h2>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 max-w-[860px] mx-auto">
          {FEATURES.map((f) => (
            <div key={f.title} className="landing-feat" style={{ padding: 32 }}>
              <div className="landing-feat-ico" style={{ background: f.color }}>
                <f.icon className="w-6 h-6 relative z-[1]" style={{ color: f.stroke }} strokeWidth={1.5} />
              </div>
              <div className="text-base font-bold mb-2 text-text-primary">{f.title}</div>
              <div className="text-[13px] text-[#8FAEA0] leading-relaxed">{f.desc}</div>
            </div>
          ))}
        </div>
      </section>

      {/* ─── PRICING ─── */}
      <section id="pricing" className="relative z-10 px-14 py-24 border-t border-[#132A21]">
        <div className="text-center mb-14">
          <SectionTag>Pricing</SectionTag>
          <h2 className="text-[44px] font-extrabold tracking-[-2px] leading-[1.05] mt-5 text-text-primary">
            Start free, <span className="landing-shimmer-text">scale as you grow</span>
          </h2>
          <p className="text-[15px] text-[#8FAEA0] mt-4">Channel access depends on your plan</p>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-5 max-w-[860px] mx-auto">
          {PLANS.map((plan) => (
            <div
              key={plan.name}
              className={`landing-price-card ${plan.primary ? 'landing-price-pop scale-[1.04]' : ''}`}
            >
              <div className="relative z-[1]">
                {plan.primary && (
                  <div className="inline-flex px-3.5 py-1 rounded-full bg-brand-soft border border-[rgba(0,255,170,0.12)] text-[11px] font-bold text-brand mb-3">
                    Most popular
                  </div>
                )}
                <div className="text-xs font-semibold text-[#4D6E5F] uppercase tracking-[2px]">
                  {plan.name}
                </div>
                <div className="text-[42px] font-black tracking-[-2px] my-3 leading-none text-text-primary">
                  {plan.price}
                  {plan.period.startsWith('/') && (
                    <span className="text-base font-medium text-[#4D6E5F]">{plan.period}</span>
                  )}
                </div>
                {!plan.period.startsWith('/') && (
                  <div className="text-[13px] text-[#4D6E5F] mb-6">{plan.period}</div>
                )}
                <div className="flex flex-col gap-3 mb-7">
                  {plan.features.map((f) => (
                    <div key={f} className="flex items-center gap-2.5 text-sm text-[#8FAEA0]">
                      <Check className="w-4 h-4 text-brand shrink-0" strokeWidth={2} />
                      {f}
                    </div>
                  ))}
                </div>
                {plan.primary ? (
                  <Link to="/auth/register" className="landing-cta w-full justify-center rounded-[14px]">
                    <span className="landing-beam" />
                    {plan.cta}
                  </Link>
                ) : (
                  <Link to="/auth/register" className="landing-cta2 w-full justify-center rounded-[14px]">
                    {plan.cta}
                  </Link>
                )}
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* ─── FINAL CTA ─── */}
      <section className="relative z-10 px-14 py-28 border-t border-[#132A21] text-center overflow-hidden">
        <div
          className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[600px] h-[600px] rounded-full pointer-events-none"
          style={{ background: 'radial-gradient(circle, rgba(0,255,170,.05), transparent 65%)' }}
        />
        <div className="relative">
          <h2 className="text-[52px] font-black tracking-[-3px] leading-none text-text-primary">
            Ready to build your
            <br />
            <span className="landing-shimmer-text">chatbot?</span>
          </h2>
          <p className="text-[17px] text-[#8FAEA0] mt-6 mb-10">
            Join teams already serving customers on every channel.
          </p>
          <CtaButton to="/auth/register" large>
            Get started for free <ArrowRight className="w-5 h-5" />
          </CtaButton>
        </div>
      </section>

      {/* ─── FOOTER ─── */}
      <footer className="relative z-10 flex items-center justify-between px-14 py-6 border-t border-[#132A21]">
        <div className="flex items-center gap-2.5">
          <div className="w-7 h-7 rounded-lg bg-brand flex items-center justify-center">
            <Zap className="w-3.5 h-3.5 text-[#050808]" strokeWidth={2.5} />
          </div>
          <span className="text-sm font-bold text-text-primary">OmniFlow</span>
        </div>
        <div className="flex gap-8 text-xs text-text-muted">
          {['Privacy', 'Terms', 'Docs', 'Support'].map((t) => (
            <span key={t} className="hover:text-text-secondary cursor-pointer transition-colors">
              {t}
            </span>
          ))}
        </div>
        <span className="text-[11px] text-text-muted">&copy; 2026 OmniFlow AI</span>
      </footer>
    </div>
  );
}
