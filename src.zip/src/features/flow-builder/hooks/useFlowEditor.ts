import { useReducer, useCallback, useRef, useEffect } from 'react';
import type { Node, Edge, OnNodesChange, OnEdgesChange, OnConnect, Connection } from '@xyflow/react';
import { applyNodeChanges, applyEdgeChanges, addEdge } from '@xyflow/react';
import type { FlowDto, FlowNodeData, FlowNodeTypeValue, FlowSaveRequest } from '../types/flow.types';
import { useSaveFlow } from '../api/flow.queries';
import { useDebounce } from '@/shared/hooks/useDebounce';

interface State {
  nodes: Node<FlowNodeData>[];
  edges: Edge[];
  flowId: string | null;
  flowName: string;
  flowVersion: number;
  isDirty: boolean;
  undoStack: { nodes: Node<FlowNodeData>[]; edges: Edge[] }[];
  redoStack: { nodes: Node<FlowNodeData>[]; edges: Edge[] }[];
}
type Action =
  | { type: 'SET_FLOW'; flow: FlowDto }
  | { type: 'SET_NODES'; nodes: Node<FlowNodeData>[] }
  | { type: 'SET_EDGES'; edges: Edge[] }
  | { type: 'ADD_NODE'; node: Node<FlowNodeData> }
  | { type: 'REMOVE_NODE'; nodeId: string }
  | { type: 'MARK_CLEAN' }
  | { type: 'UNDO' }
  | { type: 'REDO' }
  | { type: 'CLEAR' }
  | { type: 'SNAPSHOT' }
  | { type: 'SET_NAME'; name: string };

export function flowToReactFlow(flow: FlowDto) {
  const nodes: Node<FlowNodeData>[] = (flow.nodes || []).map((n) => ({
    id: n.nodeKey,
    type: n.nodeType,
    position: { x: n.positionX, y: n.positionY },
    data: {
      label: n.name,
      nodeType: n.nodeType,
      config: n.configurationJson ? JSON.parse(n.configurationJson) : {},
      intentId: n.intentId,
      capabilityId: n.capabilityId,
      apiEndpointId: n.apiEndpointId,
      isEntryPoint: n.isEntryPoint,
      backendId: n.id,
    },
  }));
  const edges: Edge[] = (flow.connections || []).map((c) => ({
    id: `${c.fromNodeKey}-${c.toNodeKey}`,
    source: c.fromNodeKey,
    target: c.toNodeKey,
    label: c.conditionLabel || undefined,
    type: 'smoothstep',
    animated: true,
    style: { stroke: '#059669', strokeWidth: 2 },
    data: { backendId: c.id },
  }));
  return { nodes, edges };
}

export function reactFlowToSave(s: State): FlowSaveRequest {
  return {
    Name: s.flowName || 'Untitled Flow',
    Nodes: s.nodes.map((n, i) => ({
      NodeKey: n.id,
      NodeType: (n.data as FlowNodeData).nodeType as FlowNodeTypeValue,
      Name: (n.data as FlowNodeData).label,
      PositionX: Math.round(n.position.x),
      PositionY: Math.round(n.position.y),
      ConfigurationJson: JSON.stringify((n.data as FlowNodeData).config || {}),
      SortOrder: i,
      IsEntryPoint: (n.data as FlowNodeData).isEntryPoint ?? false,
      IntentId: (n.data as FlowNodeData).intentId ?? null,
      CapabilityId: (n.data as FlowNodeData).capabilityId ?? null,
      ApiEndpointId: (n.data as FlowNodeData).apiEndpointId ?? null,
    })),
    Connections: s.edges.map((e, i) => ({
      FromNodeKey: e.source,
      ToNodeKey: e.target,
      ConditionLabel: (e.label as string) || null,
      SortOrder: i,
    })),
  };
}

const init: State = {
  nodes: [],
  edges: [],
  flowId: null,
  flowName: '',
  flowVersion: 1,
  isDirty: false,
  undoStack: [],
  redoStack: [],
};

function reducer(s: State, a: Action): State {
  switch (a.type) {
    case 'SET_FLOW': {
      const { nodes, edges } = flowToReactFlow(a.flow);
      return {
        ...s,
        nodes,
        edges,
        flowId: a.flow.id,
        flowName: a.flow.name,
        flowVersion: a.flow.version,
        isDirty: false,
        undoStack: [],
        redoStack: [],
      };
    }
    case 'SET_NODES':
      return { ...s, nodes: a.nodes, isDirty: true };
    case 'SET_EDGES':
      return { ...s, edges: a.edges, isDirty: true };
    case 'ADD_NODE':
      return { ...s, nodes: [...s.nodes, a.node], isDirty: true };
    case 'REMOVE_NODE':
      return {
        ...s,
        nodes: s.nodes.filter((n) => n.id !== a.nodeId),
        edges: s.edges.filter((e) => e.source !== a.nodeId && e.target !== a.nodeId),
        isDirty: true,
      };
    case 'MARK_CLEAN':
      return { ...s, isDirty: false };
    case 'SET_NAME':
      return { ...s, flowName: a.name, isDirty: true };
    case 'SNAPSHOT':
      return {
        ...s,
        undoStack: [...s.undoStack.slice(-19), { nodes: [...s.nodes], edges: [...s.edges] }],
        redoStack: [],
      };
    case 'UNDO': {
      if (!s.undoStack.length) return s;
      const p = s.undoStack[s.undoStack.length - 1];
      return {
        ...s,
        nodes: p.nodes,
        edges: p.edges,
        undoStack: s.undoStack.slice(0, -1),
        redoStack: [...s.redoStack, { nodes: [...s.nodes], edges: [...s.edges] }],
        isDirty: true,
      };
    }
    case 'REDO': {
      if (!s.redoStack.length) return s;
      const n = s.redoStack[s.redoStack.length - 1];
      return {
        ...s,
        nodes: n.nodes,
        edges: n.edges,
        redoStack: s.redoStack.slice(0, -1),
        undoStack: [...s.undoStack, { nodes: [...s.nodes], edges: [...s.edges] }],
        isDirty: true,
      };
    }
    case 'CLEAR':
      return {
        ...s,
        nodes: [],
        edges: [],
        isDirty: true,
        undoStack: [...s.undoStack, { nodes: [...s.nodes], edges: [...s.edges] }],
        redoStack: [],
      };
    default:
      return s;
  }
}

export function useFlowEditor() {
  const [state, dispatch] = useReducer(reducer, init);
  const saveFlow = useSaveFlow();
  const dirtyRef = useRef(state.isDirty);
  dirtyRef.current = state.isDirty;
  const loadedAtRef = useRef<number>(0); // timestamp of last SET_FLOW
  const debouncedDirty = useDebounce(state.isDirty, 5000);

  useEffect(() => {
    // Skip auto-save during first 3 seconds after flow load to avoid saving before canvas renders
    const elapsed = Date.now() - loadedAtRef.current;
    if (debouncedDirty && state.flowId && dirtyRef.current && elapsed > 3000)
      saveFlow.mutate(
        { id: state.flowId, data: reactFlowToSave(state) },
        { onSuccess: () => dispatch({ type: 'MARK_CLEAN' }) },
      );
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [debouncedDirty]);

  const setFlow = useCallback((f: FlowDto) => {
    loadedAtRef.current = Date.now();
    dispatch({ type: 'SET_FLOW', flow: f });
  }, []);

  const onNodesChange: OnNodesChange = useCallback(
    (c) => {
      dispatch({ type: 'SNAPSHOT' });
      dispatch({ type: 'SET_NODES', nodes: applyNodeChanges(c, state.nodes) as Node<FlowNodeData>[] });
    },
    [state.nodes],
  );

  const onEdgesChange: OnEdgesChange = useCallback(
    (c) => {
      dispatch({ type: 'SNAPSHOT' });
      dispatch({ type: 'SET_EDGES', edges: applyEdgeChanges(c, state.edges) });
    },
    [state.edges],
  );

  const onConnect: OnConnect = useCallback(
    (conn: Connection) => {
      dispatch({ type: 'SNAPSHOT' });
      dispatch({
        type: 'SET_EDGES',
        edges: addEdge(
          { ...conn, type: 'smoothstep', animated: true, style: { stroke: '#059669', strokeWidth: 2 } },
          state.edges,
        ),
      });
    },
    [state.edges],
  );

  const addNode = useCallback(
    (type: FlowNodeTypeValue, name: string, x?: number, y?: number) => {
      const maxY = state.nodes.length ? Math.max(...state.nodes.map((n) => n.position.y)) : 0;
      dispatch({ type: 'SNAPSHOT' });
      dispatch({
        type: 'ADD_NODE',
        node: {
          id: `n${state.nodes.length + 1}`,
          type,
          position: { x: x ?? 280, y: y ?? maxY + 120 },
          data: {
            label: name,
            nodeType: type,
            config: {},
            intentId: null,
            capabilityId: null,
            apiEndpointId: null,
            isEntryPoint: type === 'trigger',
            backendId: '',
          },
        },
      });
    },
    [state.nodes],
  );

  const removeNode = useCallback((id: string) => {
    dispatch({ type: 'SNAPSHOT' });
    dispatch({ type: 'REMOVE_NODE', nodeId: id });
  }, []);
  const setFlowName = useCallback((name: string) => dispatch({ type: 'SET_NAME', name }), []);
  const undo = useCallback(() => dispatch({ type: 'UNDO' }), []);
  const redo = useCallback(() => dispatch({ type: 'REDO' }), []);
  const clear = useCallback(() => dispatch({ type: 'CLEAR' }), []);
  const manualSave = useCallback(() => {
    if (state.flowId)
      saveFlow.mutate(
        { id: state.flowId, data: reactFlowToSave(state) },
        { onSuccess: () => dispatch({ type: 'MARK_CLEAN' }) },
      );
  }, [state, saveFlow]);

  return {
    ...state,
    dispatch,
    setFlow,
    setFlowName,
    onNodesChange,
    onEdgesChange,
    onConnect,
    addNode,
    removeNode,
    undo,
    redo,
    clear,
    manualSave,
    canUndo: state.undoStack.length > 0,
    canRedo: state.redoStack.length > 0,
    isSaving: saveFlow.isPending,
  };
}
