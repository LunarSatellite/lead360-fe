import { useState } from 'react';
import { Phone, Plus, Loader2, Wifi, WifiOff, BarChart3 } from 'lucide-react';
import { useChannels, useChannelStats, useHasActiveChannel } from '../api/channels.queries';
import { ChannelConnectionCard } from '../components/ChannelConnectionCard';
import { AvailableChannelCard } from '../components/AvailableChannelCard';
import { CreateChannelDialog } from '../components/CreateChannelDialog';
import { ChannelConnectModal } from '../components/ChannelConnectModal';
import type { ChannelConnectionDto, ChannelStatsResponse, ChannelTypeValue } from '../types/channels.types';
import { CHANNEL_TYPE_LABEL, ChannelType, ChannelConnectionStatus } from '../types/channels.types';

const ALL_CHANNEL_TYPES: ChannelTypeValue[] = [
  ChannelType.WhatsApp,
  ChannelType.Messenger,
  ChannelType.Instagram,
  ChannelType.Telegram,
  ChannelType.SMS,
  ChannelType.Voice,
  ChannelType.WebChat,
  ChannelType.Email,
];

export function Component() {
  const [createOpen, setCreateOpen] = useState(false);
  const [connectType, setConnectType] = useState<ChannelTypeValue | null>(null);
  const tenantId = localStorage.getItem('omniflow_tenant_id') ?? '';

  const { data: connectionsRaw, isLoading } = useChannels();
  const { data: statsRaw } = useChannelStats();
  useHasActiveChannel();

  const connections = (connectionsRaw as unknown as ChannelConnectionDto[]) ?? [];
  const stats = (statsRaw as unknown as ChannelStatsResponse) ?? null;

  const activeConns = connections.filter((c) => c.status === ChannelConnectionStatus.Active);
  const pausedConns = connections.filter((c) => c.status !== ChannelConnectionStatus.Active);
  const activeCount = activeConns.length;
  const totalCount = connections.length;

  const connectedTypes = new Set(connections.map((c) => c.channelType));
  const availableTypes = ALL_CHANNEL_TYPES.filter((t) => !connectedTypes.has(t));

  // Sort active connections by most messages (largest first for bento hero)
  const sortedActive = [...activeConns].sort((a, b) => {
    // Put most recently active first as a proxy for "primary"
    const aTime = a.lastMessageReceivedAt ? new Date(a.lastMessageReceivedAt).getTime() : 0;
    const bTime = b.lastMessageReceivedAt ? new Date(b.lastMessageReceivedAt).getTime() : 0;
    return bTime - aTime;
  });

  // Hero = first active, rest = secondary
  const heroConn = sortedActive[0] || null;
  const secondaryConns = sortedActive.slice(1);

  return (
    <div className="space-y-4">
      {/* ═══ HEADER ═══ */}
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-3">
          {/* Orbital engine icon */}
          <div className="relative w-9 h-9">
            <svg viewBox="0 0 36 36" className="absolute inset-0 animate-[spin_8s_linear_infinite]">
              <circle
                cx="18"
                cy="18"
                r="16"
                fill="none"
                stroke="rgba(0,217,126,0.12)"
                strokeWidth="1"
                strokeDasharray="3 5"
              />
            </svg>
            <div className="absolute inset-[6px] rounded-full bg-brand-soft flex items-center justify-center">
              <svg
                width="14"
                height="14"
                viewBox="0 0 24 24"
                fill="none"
                stroke="currentColor"
                strokeWidth="1.5"
                className="text-brand"
              >
                <circle cx="12" cy="12" r="3" />
                <path d="M12 1v2M12 21v2" />
              </svg>
            </div>
          </div>
          <div>
            <h1 className="text-lg font-bold text-text-primary tracking-tight">Channels</h1>
            <p className="text-xs text-text-secondary">
              <span className="text-success">{activeCount} live</span>
              {pausedConns.length > 0 && (
                <>
                  {' '}
                  · <span className="text-warning">{pausedConns.length} paused</span>
                </>
              )}
              {stats && <> · {totalCount} connected</>}
            </p>
          </div>
        </div>
        <button
          onClick={() => setCreateOpen(true)}
          className="flex items-center gap-2 px-5 py-2.5 rounded-[10px] bg-brand text-bg
                     text-sm font-semibold hover:bg-brand-light hover:-translate-y-px
                     hover:shadow-[0_4px_12px_rgba(0,217,126,0.15)] transition-all"
        >
          <Plus className="w-4 h-4" strokeWidth={2.5} />
          Add channel
        </button>
      </div>

      {/* ═══ ZONE 1: YOUR CHANNELS ═══ */}
      {isLoading ? (
        <div className="flex items-center justify-center py-20">
          <Loader2 className="w-6 h-6 text-brand animate-spin" />
        </div>
      ) : connections.length === 0 ? (
        <div className="rounded-[14px] bg-bg-shell border border-border-subtle p-16 flex flex-col items-center justify-center text-center">
          <div className="w-14 h-14 rounded-xl bg-glass-2 flex items-center justify-center mb-4">
            <Phone className="w-7 h-7 text-text-muted" strokeWidth={1.6} />
          </div>
          <p className="text-base font-bold text-text-primary">No channels connected</p>
          <p className="text-sm text-text-secondary mt-1 max-w-sm">
            Choose from the available connectors below to start receiving messages on any platform.
          </p>
        </div>
      ) : (
        <div className="rounded-[14px] bg-bg-shell border border-border-subtle p-4">
          <div className="flex items-center gap-2 mb-4 px-1">
            <div className="w-[6px] h-[6px] rounded-full bg-success" />
            <span className="text-sm font-semibold text-text-primary">Your channels</span>
            <span className="text-xs text-text-muted">{connections.length} connected</span>
          </div>

          {/* Bento grid */}
          <div className="grid grid-cols-12 gap-3">
            {/* Hero: first active channel — 7 cols */}
            {heroConn && (
              <div className="col-span-7">
                <ChannelConnectionCard connection={heroConn} variant="hero" />
              </div>
            )}

            {/* Secondary active channels — 5 cols each */}
            {secondaryConns.map((conn) => (
              <div key={conn.id} className="col-span-5">
                <ChannelConnectionCard connection={conn} variant="medium" />
              </div>
            ))}

            {/* Paused channels — full width bar style */}
            {pausedConns.map((conn) => (
              <div key={conn.id} className="col-span-12">
                <ChannelConnectionCard connection={conn} variant="bar" />
              </div>
            ))}
          </div>
        </div>
      )}

      {/* ═══ ZONE 2: AVAILABLE CHANNELS ═══ */}
      {availableTypes.length > 0 && (
        <div className="rounded-[14px] bg-bg-shell border border-border-subtle p-4">
          <div className="flex items-center gap-2 mb-4 px-1">
            <Plus className="w-3.5 h-3.5 text-text-muted" strokeWidth={1.5} />
            <span className="text-sm font-semibold text-text-secondary">Available to connect</span>
            <span className="text-xs text-text-muted">{availableTypes.length} channels</span>
          </div>

          <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-5 gap-3">
            {availableTypes.map((type) => (
              <AvailableChannelCard key={type} channelType={type} onConnect={(ct) => setConnectType(ct)} />
            ))}
          </div>
        </div>
      )}

      {/* Dialogs */}
      <CreateChannelDialog tenantId={tenantId} open={createOpen} onClose={() => setCreateOpen(false)} />
      {connectType !== null && (
        <ChannelConnectModal
          open={true}
          onClose={() => setConnectType(null)}
          tenantId={tenantId}
          channelType={connectType}
        />
      )}
    </div>
  );
}
