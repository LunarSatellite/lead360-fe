import { useState } from 'react';
import { useForm } from 'react-hook-form';
import { X, Plus, Loader2, Copy, Check, ExternalLink } from 'lucide-react';
import { useCreateChannel, useActivateChannel } from '../api/channels.queries';
import { ChannelType, CHANNEL_TYPE_LABEL } from '../types/channels.types';
import type { ChannelTypeValue, ChannelConnectionDto } from '../types/channels.types';

interface ChannelConnectModalProps {
  open: boolean;
  onClose: () => void;
  tenantId: string;
  channelType: ChannelTypeValue;
}

interface ConnectFormData {
  channelIdentifier: string;
  displayName: string;
  [key: string]: string;
}

// ─── Channel-specific field definitions ───

interface FieldDef {
  name: string;
  label: string;
  placeholder: string;
  type?: 'text' | 'password' | 'number';
  required?: boolean;
}

const CHANNEL_FIELDS: Record<ChannelTypeValue, FieldDef[]> = {
  [ChannelType.WhatsApp]: [
    { name: 'channelIdentifier', label: 'Phone Number', placeholder: '+254700000000', required: true },
    { name: 'displayName', label: 'Display Name', placeholder: 'Main WhatsApp' },
    {
      name: 'phoneNumberId',
      label: 'Phone Number ID',
      placeholder: 'From Meta Developer Console',
      required: true,
    },
    { name: 'accessToken', label: 'Access Token', placeholder: 'EAAx...', type: 'password', required: true },
    { name: 'appSecret', label: 'App Secret', placeholder: 'From Meta App Dashboard', type: 'password' },
    { name: 'businessAccountId', label: 'Business Account ID', placeholder: 'WhatsApp Business Account ID' },
  ],
  [ChannelType.Telegram]: [
    { name: 'channelIdentifier', label: 'Bot Username', placeholder: '@YourBotUsername', required: true },
    { name: 'displayName', label: 'Display Name', placeholder: 'Support Bot' },
    {
      name: 'botToken',
      label: 'Bot Token',
      placeholder: 'From @BotFather',
      type: 'password',
      required: true,
    },
    { name: 'secretToken', label: 'Secret Token (optional)', placeholder: 'Optional webhook verification' },
  ],
  [ChannelType.SMS]: [
    { name: 'channelIdentifier', label: 'SMS Number', placeholder: '+254700000000', required: true },
    { name: 'displayName', label: 'Display Name', placeholder: 'Support SMS' },
    { name: 'accountSid', label: 'Twilio Account SID', placeholder: 'ACxxxxxxxx', required: true },
    {
      name: 'authToken',
      label: 'Auth Token',
      placeholder: 'Twilio auth token',
      type: 'password',
      required: true,
    },
    { name: 'fromNumber', label: 'From Number', placeholder: '+1234567890' },
  ],
  [ChannelType.Voice]: [
    { name: 'channelIdentifier', label: 'Twilio Number', placeholder: '+254700000000', required: true },
    { name: 'displayName', label: 'Display Name', placeholder: 'Support Line' },
    { name: 'accountSid', label: 'Account SID', placeholder: 'ACxxxxxxxx', required: true },
    {
      name: 'authToken',
      label: 'Auth Token',
      placeholder: 'Twilio auth token',
      type: 'password',
      required: true,
    },
    { name: 'voiceName', label: 'Voice Name', placeholder: 'en-US-Neural2-C' },
    { name: 'language', label: 'Language', placeholder: 'en-US' },
  ],
  [ChannelType.Messenger]: [
    { name: 'channelIdentifier', label: 'Facebook Page ID', placeholder: '1234567890', required: true },
    { name: 'displayName', label: 'Display Name', placeholder: 'Business Messenger' },
    {
      name: 'pageAccessToken',
      label: 'Page Access Token',
      placeholder: 'From Facebook Developer Console',
      type: 'password',
      required: true,
    },
    { name: 'appSecret', label: 'App Secret', placeholder: 'From Meta App Settings', type: 'password' },
  ],
  [ChannelType.Instagram]: [
    { name: 'channelIdentifier', label: 'IG Business Account ID', placeholder: '1234567890', required: true },
    { name: 'displayName', label: 'Display Name', placeholder: 'Brand Instagram' },
    {
      name: 'pageAccessToken',
      label: 'Page Access Token',
      placeholder: 'From Facebook Developer Console',
      type: 'password',
      required: true,
    },
    { name: 'appSecret', label: 'App Secret', placeholder: 'From Meta App Settings', type: 'password' },
  ],
  [ChannelType.WebChat]: [
    { name: 'channelIdentifier', label: 'Website Domain', placeholder: 'www.example.com', required: true },
    { name: 'displayName', label: 'Display Name', placeholder: 'Website Chat Widget' },
    {
      name: 'allowedOrigins',
      label: 'Allowed Origins',
      placeholder: 'https://example.com, https://app.example.com',
    },
    { name: 'theme', label: 'Theme', placeholder: 'light or dark' },
  ],
  [ChannelType.Email]: [
    {
      name: 'channelIdentifier',
      label: 'Support Email Address',
      placeholder: 'support@example.com',
      required: true,
    },
    { name: 'displayName', label: 'Display Name', placeholder: 'Customer Support Email' },
    { name: 'smtpHost', label: 'SMTP Host', placeholder: 'smtp.gmail.com', required: true },
    { name: 'smtpPort', label: 'SMTP Port', placeholder: '587', type: 'number' },
    { name: 'smtpUsername', label: 'SMTP Username', placeholder: 'user@example.com' },
    { name: 'smtpPassword', label: 'SMTP Password', placeholder: 'App password', type: 'password' },
    { name: 'fromAddress', label: 'From Address', placeholder: 'noreply@example.com' },
    { name: 'fromName', label: 'From Name', placeholder: 'Acme Support' },
    { name: 'replyTo', label: 'Reply-To Address', placeholder: 'support@example.com' },
  ],
};

const CHANNEL_HELPER_TEXT: Record<ChannelTypeValue, string> = {
  [ChannelType.WhatsApp]: 'Get these credentials from your Meta Developer Console → WhatsApp → API Setup.',
  [ChannelType.Telegram]: 'Create a bot with @BotFather on Telegram and paste the token here.',
  [ChannelType.SMS]: 'Get Account SID and Auth Token from your Twilio Console.',
  [ChannelType.Voice]: 'Configure Twilio Voice settings in the Twilio Console.',
  [ChannelType.Messenger]: 'Get Page Access Token from Facebook Developer Console → Messenger.',
  [ChannelType.Instagram]: 'Link your Instagram Business Account through the Meta Business Suite.',
  [ChannelType.WebChat]: 'Widget token will be auto-generated. Add allowed origins for your website.',
  [ChannelType.Email]: 'Configure SMTP settings for your email provider.',
};

const WEBHOOK_INSTRUCTIONS: Record<ChannelTypeValue, string> = {
  [ChannelType.WhatsApp]:
    'Paste this webhook URL in Meta Developer Console → WhatsApp → Configuration → Callback URL.',
  [ChannelType.Telegram]: 'The webhook is set automatically via the Telegram Bot API.',
  [ChannelType.SMS]: 'Paste this webhook URL in Twilio Console → Phone Numbers → Messaging Webhook.',
  [ChannelType.Voice]: 'Paste this webhook URL in Twilio Console → Phone Numbers → Voice Webhook.',
  [ChannelType.Messenger]: 'Paste this webhook URL in Meta Developer Console → Messenger → Webhooks.',
  [ChannelType.Instagram]: 'Paste this webhook URL in Meta Developer Console → Instagram → Webhooks.',
  [ChannelType.WebChat]: 'Embed the OmniFlow chat widget script on your website using this endpoint.',
  [ChannelType.Email]: 'Configure your email provider to forward incoming emails to this webhook URL.',
};

export function ChannelConnectModal({ open, onClose, tenantId, channelType }: ChannelConnectModalProps) {
  const [step, setStep] = useState<'config' | 'success'>('config');
  const [createdChannel, setCreatedChannel] = useState<ChannelConnectionDto | null>(null);
  const [copied, setCopied] = useState(false);

  const create = useCreateChannel();
  const activate = useActivateChannel();

  const fields = CHANNEL_FIELDS[channelType] ?? [];
  const label = CHANNEL_TYPE_LABEL[channelType];
  const helperText = CHANNEL_HELPER_TEXT[channelType];

  const form = useForm<ConnectFormData>({
    defaultValues: Object.fromEntries(fields.map((f) => [f.name, ''])),
  });

  const onSubmit = (data: ConnectFormData) => {
    // Separate standard fields from config fields
    const { channelIdentifier, displayName, ...configFields } = data;

    // Build configurationJson from remaining fields
    const configJson = Object.keys(configFields).length > 0 ? JSON.stringify(configFields) : undefined;

    create.mutate(
      {
        tenantId,
        channelType,
        channelIdentifier,
        displayName: displayName || undefined,
        configurationJson: configJson,
      },
      {
        onSuccess: (result) => {
          const channel = result as unknown as ChannelConnectionDto;
          setCreatedChannel(channel);
          // Auto-activate after creation
          if (channel?.id) {
            activate.mutate(channel.id);
          }
          setStep('success');
        },
      },
    );
  };

  const handleCopyWebhook = () => {
    if (createdChannel?.webhookUrl) {
      navigator.clipboard.writeText(createdChannel.webhookUrl);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    }
  };

  const handleClose = () => {
    setStep('config');
    setCreatedChannel(null);
    form.reset();
    onClose();
  };

  if (!open) return null;

  const inputClass =
    'w-full px-4 py-2.5 rounded-lg bg-glass-2 border border-border-subtle text-sm text-text-primary placeholder:text-text-muted focus:outline-none focus:border-brand transition-all';
  const labelClass = 'text-2xs font-bold uppercase tracking-[2px] text-text-muted block mb-2';

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center">
      <div className="fixed inset-0 bg-black/60 backdrop-blur-sm" onClick={handleClose} />
      <div className="relative w-full max-w-lg mx-4 bg-bg-shell border border-border-medium rounded-2xl overflow-hidden max-h-[90vh] flex flex-col">
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-b-border-subtle flex-shrink-0">
          <h2 className="text-lg font-extrabold text-text-primary tracking-tight">
            {step === 'config' ? `Connect ${label}` : `${label} connected!`}
          </h2>
          <button
            onClick={handleClose}
            className="w-8 h-8 rounded-lg bg-glass-2 flex items-center justify-center text-text-muted hover:text-text-primary transition-all"
          >
            <X className="w-4 h-4" strokeWidth={1.8} />
          </button>
        </div>

        {step === 'config' ? (
          /* ─── Configuration Step ─── */
          <form onSubmit={form.handleSubmit(onSubmit)} className="flex-1 overflow-y-auto p-6 space-y-4">
            {/* Helper text */}
            <div className="px-4 py-3 rounded-lg bg-info-soft border border-[rgba(59,130,246,0.12)] text-sm text-info">
              {helperText}
            </div>

            {/* Dynamic fields */}
            {fields.map((field) => (
              <div key={field.name}>
                <label className={labelClass}>
                  {field.label} {field.required && <span className="text-danger">*</span>}
                </label>
                <input
                  {...form.register(field.name, {
                    required: field.required ? `${field.label} is required` : false,
                  })}
                  type={field.type || 'text'}
                  placeholder={field.placeholder}
                  className={inputClass}
                />
                {form.formState.errors[field.name] && (
                  <p className="text-2xs text-danger mt-1">
                    {form.formState.errors[field.name]?.message as string}
                  </p>
                )}
              </div>
            ))}

            {/* Error */}
            {create.isError && (
              <div className="px-4 py-3 rounded-lg bg-danger-soft border border-[rgba(244,63,94,0.15)] text-sm text-danger">
                {create.error?.message || 'Failed to create channel.'}
              </div>
            )}

            {/* Actions */}
            <div className="flex justify-end gap-3 pt-2">
              <button
                type="button"
                onClick={handleClose}
                className="px-4 py-2.5 rounded-lg bg-glass-2 border border-border-medium text-sm font-semibold text-text-secondary hover:text-text-primary transition-all"
              >
                Cancel
              </button>
              <button
                type="submit"
                disabled={create.isPending}
                className="flex items-center gap-2 px-5 py-2.5 rounded-lg bg-gradient-to-br from-brand to-brand-dark text-sm font-bold text-white hover:brightness-110 disabled:opacity-50 transition-all"
              >
                {create.isPending ? (
                  <Loader2 className="w-4 h-4 animate-spin" />
                ) : (
                  <Plus className="w-4 h-4" strokeWidth={2} />
                )}
                {create.isPending ? 'Connecting...' : 'Connect channel'}
              </button>
            </div>
          </form>
        ) : (
          /* ─── Success Step with Webhook URL ─── */
          <div className="p-6 space-y-5">
            {/* Success badge */}
            <div className="flex items-center gap-3 px-4 py-3 rounded-lg bg-success-soft border border-[rgba(6,214,160,0.15)]">
              <div className="w-8 h-8 rounded-full bg-success flex items-center justify-center">
                <Check className="w-4 h-4 text-text-primary" strokeWidth={2.5} />
              </div>
              <div>
                <p className="text-sm font-bold text-success">Channel connected successfully</p>
                <p className="text-2xs text-success/70 mt-0.5">
                  {createdChannel?.displayName || label} is now ready to receive messages.
                </p>
              </div>
            </div>

            {/* Webhook URL */}
            {createdChannel?.webhookUrl && (
              <div>
                <label className="text-2xs font-bold uppercase tracking-[2px] text-text-muted block mb-2">
                  Webhook URL
                </label>
                <div className="flex items-center gap-2 px-4 py-3 rounded-lg bg-glass-2 border border-border-medium">
                  <ExternalLink className="w-4 h-4 text-text-muted flex-shrink-0" strokeWidth={1.6} />
                  <span className="text-xs font-mono text-brand truncate flex-1">
                    {createdChannel.webhookUrl}
                  </span>
                  <button
                    onClick={handleCopyWebhook}
                    className="flex-shrink-0 px-3 py-1.5 rounded-md bg-glass-3 border border-border-subtle text-2xs font-bold text-text-secondary hover:text-text-primary transition-all"
                  >
                    {copied ? (
                      <span className="flex items-center gap-1 text-success">
                        <Check className="w-3 h-3" strokeWidth={2} /> Copied
                      </span>
                    ) : (
                      <span className="flex items-center gap-1">
                        <Copy className="w-3 h-3" strokeWidth={1.6} /> Copy
                      </span>
                    )}
                  </button>
                </div>
              </div>
            )}

            {/* Setup instructions */}
            <div className="px-4 py-3 rounded-lg bg-warning-soft border border-[rgba(245,158,11,0.1)]">
              <p className="text-2xs font-bold uppercase tracking-[2px] text-warning mb-1.5">Next step</p>
              <p className="text-sm text-text-secondary leading-relaxed">
                {WEBHOOK_INSTRUCTIONS[channelType]}
              </p>
            </div>

            {/* Done */}
            <div className="flex justify-end pt-2">
              <button
                onClick={handleClose}
                className="px-5 py-2.5 rounded-lg bg-gradient-to-br from-brand to-brand-dark text-sm font-bold text-white hover:brightness-110 transition-all"
              >
                Done
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
