interface Message {
  role: 'user' | 'bot';
  text: string;
  buttons?: { label: string; value: string }[];
}

interface WhatsAppPreviewProps {
  messages: Message[];
  onButtonClick: (value: string) => void;
}

export function WhatsAppPreview({ messages, onButtonClick }: WhatsAppPreviewProps) {
  return (
    <div className="flex flex-col h-full">
      {/* Header */}
      <div className="flex items-center gap-2 px-3 py-2 bg-[#075E54] text-white">
        <div className="w-8 h-8 rounded-full bg-[#25D366] flex items-center justify-center text-xs font-bold">🤖</div>
        <div className="flex-1 min-w-0">
          <div className="text-xs font-semibold truncate">OmniFlow Bot</div>
          <div className="text-[10px] opacity-70">online</div>
        </div>
      </div>

      {/* Messages */}
      <div
        className="flex-1 overflow-auto p-2 space-y-1.5"
        style={{ background: '#ECE5DD url("data:image/svg+xml,%3Csvg width=\'300\' height=\'300\' xmlns=\'http://www.w3.org/2000/svg\'%3E%3Ctext x=\'50%25\' y=\'50%25\' text-anchor=\'middle\' fill=\'%23d5cec0\' font-size=\'12\'%3E%3C/text%3E%3C/svg%3E")' }}
      >
        {messages.length === 0 && (
          <div className="text-center py-6 text-[10px] text-[#8a8a8a]">Send a message to start</div>
        )}
        {messages.map((m, i) => (
          <div key={i} className={`flex ${m.role === 'user' ? 'justify-end' : 'justify-start'}`}>
            <div className="max-w-[85%]">
              <div
                className="px-2.5 py-1.5 text-[11px] leading-relaxed whitespace-pre-wrap"
                style={{
                  borderRadius: 8,
                  ...(m.role === 'user'
                    ? { background: '#DCF8C6', borderTopRightRadius: 0 }
                    : { background: '#fff', borderTopLeftRadius: 0 }),
                }}
              >
                {m.text}
              </div>
              {m.buttons && m.buttons.length > 0 && (
                <div className="mt-1 space-y-0.5">
                  {m.buttons.slice(0, 3).map((b, j) => (
                    <button
                      key={j}
                      onClick={() => onButtonClick(b.value)}
                      className="w-full py-1.5 rounded-md bg-white border border-[#ccc] text-[11px] font-medium text-[#075E54] hover:bg-[#f0f0f0] transition-colors text-center"
                    >
                      {b.label}
                    </button>
                  ))}
                </div>
              )}
              <div className="text-[9px] text-[#8a8a8a] mt-0.5 text-right">
                {new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
