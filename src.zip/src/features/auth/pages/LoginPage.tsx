import { useState } from 'react';
import { useNavigate, Link, useLocation } from 'react-router-dom';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { Eye, EyeOff } from 'lucide-react';
import { loginSchema, type LoginFormData } from '../types/auth.schemas';
import { useLogin } from '../api/auth.queries';

export function Component() {
  const navigate = useNavigate();
  const location = useLocation();
  const login = useLogin();
  const [showPw, setShowPw] = useState(false);
  const form = useForm<LoginFormData>({
    resolver: zodResolver(loginSchema),
    defaultValues: { email: '', password: '' },
  });

  const from = (location.state as { from?: { pathname: string } })?.from?.pathname || '/dashboard';

  const onSubmit = (data: LoginFormData) => {
    login.mutate(data, { onSuccess: () => navigate(from, { replace: true }) });
  };

  return (
    <div className="space-y-8">
      <div>
        <h1 className="text-3xl font-extrabold text-text-primary tracking-tight">Welcome back</h1>
        <p className="text-base text-text-secondary mt-2">Sign in to your workspace</p>
      </div>

      <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-5">
        {/* Email */}
        <div>
          <label className="text-sm font-semibold text-text-primary block mb-2">Email address</label>
          <input
            {...form.register('email')}
            type="email"
            placeholder="you@company.com"
            autoComplete="email"
            className="w-full px-4 py-3 rounded-xl bg-bg-input border border-border-subtle text-base text-text-primary placeholder:text-text-muted focus:outline-none focus:border-brand focus:shadow-[0_0_0_3px_rgba(0,217,126,0.1)] transition-all"
          />
          {form.formState.errors.email && (
            <p className="text-xs text-danger mt-1.5">{form.formState.errors.email.message}</p>
          )}
        </div>

        {/* Password */}
        <div>
          <div className="flex justify-between mb-2">
            <label className="text-sm font-semibold text-text-primary">Password</label>
            <Link
              to="/auth/forgot-password"
              className="text-sm text-brand font-semibold hover:text-brand-light transition-colors"
            >
              Forgot?
            </Link>
          </div>
          <div className="relative">
            <input
              {...form.register('password')}
              type={showPw ? 'text' : 'password'}
              placeholder="••••••••••"
              autoComplete="current-password"
              className="w-full px-4 py-3 pr-12 rounded-xl bg-bg-input border border-border-subtle text-base text-text-primary placeholder:text-text-muted focus:outline-none focus:border-brand focus:shadow-[0_0_0_3px_rgba(0,217,126,0.1)] transition-all"
            />
            <button
              type="button"
              onClick={() => setShowPw(!showPw)}
              className="absolute right-4 top-1/2 -translate-y-1/2 text-text-muted hover:text-text-secondary transition-colors"
            >
              {showPw ? <EyeOff className="w-5 h-5" /> : <Eye className="w-5 h-5" />}
            </button>
          </div>
          {form.formState.errors.password && (
            <p className="text-xs text-danger mt-1.5">{form.formState.errors.password.message}</p>
          )}
        </div>

        {/* Error */}
        {login.isError && (
          <div className="px-4 py-3 rounded-xl bg-danger-soft border border-[rgba(244,63,94,0.15)] text-sm text-danger">
            {login.error?.message || 'Login failed.'}
          </div>
        )}

        {/* Submit */}
        <button
          type="submit"
          disabled={login.isPending}
          className="w-full flex items-center justify-center gap-2.5 py-3.5 rounded-xl text-bg text-base font-bold bg-brand hover:bg-brand-light disabled:opacity-50 transition-all"
        >
          {login.isPending ? (
            <span className="w-5 h-5 border-2 border-bg/30 border-t-bg rounded-full animate-spin" />
          ) : null}
          {login.isPending ? 'Signing in...' : 'Sign in'}
        </button>
      </form>

      {/* Divider */}
      <div className="flex items-center gap-4">
        <div className="flex-1 h-px bg-border-subtle" />
        <span className="text-xs text-text-muted uppercase tracking-wider">or</span>
        <div className="flex-1 h-px bg-border-subtle" />
      </div>

      {/* Google */}
      <button
        type="button"
        className="w-full flex items-center justify-center gap-3 py-3 rounded-xl border border-border-subtle bg-bg-card text-sm font-semibold text-text-primary hover:bg-bg-elevated transition-all"
      >
        <svg className="w-5 h-5" viewBox="0 0 24 24">
          <path
            d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92a5.06 5.06 0 01-2.2 3.32v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.1z"
            fill="#4285F4"
          />
          <path
            d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"
            fill="#34A853"
          />
          <path
            d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18A10.96 10.96 0 001 12c0 1.77.42 3.45 1.18 4.93l3.66-2.84z"
            fill="#FBBC05"
          />
          <path
            d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z"
            fill="#EA4335"
          />
        </svg>
        Continue with Google
      </button>

      <p className="text-center text-sm text-text-muted">
        No account?{' '}
        <Link
          to="/auth/register"
          className="text-brand font-semibold hover:text-brand-light transition-colors"
        >
          Create one free
        </Link>
      </p>
    </div>
  );
}
