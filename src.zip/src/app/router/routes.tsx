import { createBrowserRouter, Navigate } from 'react-router-dom';
import { AuthLayout } from '@/app/layouts/AuthLayout';
import { DashboardLayout } from '@/app/layouts/DashboardLayout';
import { RequireAuth, RedirectIfAuth } from './guards';

export const router = createBrowserRouter([
  // ─── Landing — logged in users skip to dashboard ───
  {
    path: '/',
    lazy: async () => {
      const token = localStorage.getItem('omniflow_token');
      if (token) {
        return { Component: () => <Navigate to="/dashboard/setup" replace /> };
      }
      return import('@/features/landing/pages/LandingPage');
    },
  },

  // ─── Auth — redirect if already logged in ───
  {
    path: '/auth',
    element: (
      <RedirectIfAuth>
        <AuthLayout />
      </RedirectIfAuth>
    ),
    children: [
      { path: 'login', lazy: () => import('@/features/auth/pages/LoginPage')},
      { path: 'register', lazy: () => import('@/features/auth/pages/RegisterPage') },
      { path: 'forgot-password', lazy: () => import('@/features/auth/pages/ForgotPasswordPage') },
      { path: 'reset-password', lazy: () => import('@/features/auth/pages/ResetPasswordPage') },
    ],
  },

  // ─── Verify email — public ───
  {
    path: '/verify-email',
    element: <AuthLayout />,
    children: [{ index: true, lazy: () => import('@/features/auth/pages/VerifyEmailPage') }],
  },

  // ─── Accept invitation — public ───
  {
    path: '/accept-invitation',
    element: <AuthLayout />,
    children: [{ index: true, lazy: () => import('@/features/team/pages/AcceptInvitationPage') }],
  },

  // ─── Dashboard (protected) ───
  {
    path: '/dashboard',
    element: (
      <RequireAuth>
        <DashboardLayout />
      </RequireAuth>
    ),
    children: [
      { path: 'setup', lazy: () => import('@/features/tenant/pages/SetupPage') },
      { path: 'settings', lazy: () => import('@/features/auth/pages/AccountSettingsPage') },
      { path: 'intents', lazy: () => import('@/features/intents/pages/IntentListPage') },
      { path: 'api-specs', element: <Navigate to="/dashboard/api-connection" replace /> },
      { path: 'api-specs/:id', element: <Navigate to="/dashboard/api-connection" replace /> },
      { path: 'api-connection', lazy: () => import('@/features/api-connection/pages/ApiConnectionPage') },
      { path: 'api-connection/:specId', lazy: () => import('@/features/api-connection/pages/ApiSpecDetailPage') },
      { path: 'intent-suggestions', element: <Navigate to="/dashboard/api-connection" replace /> },
      { path: 'catalog', lazy: () => import('@/features/catalog/pages/CatalogDashboardPage') },
      { path: 'flows', lazy: () => import('@/features/flow-builder/pages/FlowBuilderPage') },
      { path: 'channels', lazy: () => import('@/features/channels/pages/ChannelListPage') },
      { path: 'test-channel', lazy: () => import('@/features/test-channel/pages/TestChannelPage') },
      { path: 'conversations', lazy: () => import('@/features/conversations/pages/ConversationsPage') },
      { path: 'analytics', lazy: () => import('@/features/analytics/pages/AnalyticsPage') },
      { path: 'compliance', lazy: () => import('@/features/compliance/pages/ComplianceSettings') },
      { path: 'onboarding', lazy: () => import('@/features/onboarding/pages/OnboardingPage') },
      { path: 'team', element: <Navigate to="/dashboard/settings" replace /> },
      { index: true, element: <Navigate to="setup" replace /> },
    ],
  },

  // ─── Legacy redirects ───
  { path: '/biz/*', element: <Navigate to="/dashboard/setup" replace /> },
  { path: '/tech/*', element: <Navigate to="/dashboard/setup" replace /> },
]);
