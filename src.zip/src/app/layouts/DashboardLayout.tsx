import { useState, useRef, useEffect } from 'react';
import { Outlet, NavLink, useLocation, useNavigate } from 'react-router-dom';
import {
  LayoutGrid,
  Target,
  MessageSquare,
  GitBranch,
  Phone,
  BarChart3,
  Settings,
  Zap,
  LogOut,
  User,
  ChevronDown,
  Terminal,
  Bot,
  Plug,
  Package,
  Rocket,
} from 'lucide-react';
import { ROUTES } from '@/app/router/route-paths';
import { useLogout, useProfile } from '@/features/auth/api/auth.queries';

const buildNav = [
  { label: 'Conversation Map', href: ROUTES.dashboard.flows, icon: GitBranch, badge: 'AI' },
  { label: 'Test Channel', href: ROUTES.dashboard.testChannel, icon: Terminal },
  { label: 'Setup Wizard', href: ROUTES.dashboard.onboarding, icon: Rocket },
];

const configureNav = [
  { label: 'Setup', href: ROUTES.dashboard.setup, icon: LayoutGrid },
  { label: 'Intents', href: ROUTES.dashboard.intents, icon: Target },
  { label: 'API Pipeline', href: ROUTES.dashboard.apiConnection, icon: Plug },
  { label: 'Catalog', href: ROUTES.dashboard.catalog, icon: Package },
  { label: 'Channels', href: ROUTES.dashboard.channels, icon: Phone },
  { label: 'Conversations', href: ROUTES.dashboard.conversations, icon: MessageSquare },
  { label: 'Analytics', href: ROUTES.dashboard.analytics, icon: BarChart3 },
];

const settingsNav = [{ label: 'Settings', href: '/dashboard/settings', icon: Settings }];

export function DashboardLayout() {
  const location = useLocation();
  const logout = useLogout();
  const { data: profile } = useProfile();
  const [menuOpen, setMenuOpen] = useState(false);
  const [sidebarExpanded, setSidebarExpanded] = useState(false);
  const menuRef = useRef<HTMLDivElement>(null);
  const navigate = useNavigate();

  useEffect(() => {
    const handler = (e: MouseEvent) => {
      if (menuRef.current && !menuRef.current.contains(e.target as Node)) setMenuOpen(false);
    };
    document.addEventListener('mousedown', handler);
    return () => document.removeEventListener('mousedown', handler);
  }, []);

  const profileData = profile as any;
  const initials = profileData
    ? `${(profileData.firstName?.[0] || '').toUpperCase()}${(profileData.lastName?.[0] || '').toUpperCase()}`
    : 'U';
  const displayName = profileData
    ? `${profileData.firstName || ''} ${profileData.lastName || ''}`.trim()
    : 'User';
  const displayEmail = profileData?.email || '';
  const displayRole = profileData?.role || 'Admin';

  const getPageTitle = () => {
    const path = location.pathname;
    if (path.includes('/onboarding')) return 'Setup Wizard';
    if (path.includes('/flows')) return 'AI Flow Builder';
    if (path.includes('/test-channel')) return 'Simulator';
    if (path.includes('/setup')) return 'Setup';
    if (path.includes('/api-connection')) return 'API Pipeline';
    if (path.includes('/catalog')) return 'Catalog';
    if (path.includes('/intents')) return 'Intents';
    if (path.includes('/channels')) return 'Channels';
    if (path.includes('/conversations')) return 'Conversations';
    if (path.includes('/analytics')) return 'Analytics';
    if (path.includes('/compliance')) return 'Compliance';
    if (path.includes('/settings')) return 'Settings';
    return 'Dashboard';
  };

  const getPageIcon = () => {
    const path = location.pathname;
    if (path.includes('/flows')) return GitBranch;
    if (path.includes('/test-channel')) return Terminal;
    if (path.includes('/onboarding')) return Rocket;
    if (path.includes('/setup')) return LayoutGrid;
    if (path.includes('/intents')) return Target;
    if (path.includes('/api-connection')) return Plug;
    if (path.includes('/catalog')) return Package;
    if (path.includes('/channels')) return Phone;
    if (path.includes('/conversations')) return MessageSquare;
    if (path.includes('/analytics')) return BarChart3;
    if (path.includes('/settings')) return Settings;
    return LayoutGrid;
  };

  const PageIcon = getPageIcon();

  const renderNavItem = (item: { label: string; href: string; icon: any; badge?: string }) => {
    const isActive = location.pathname === item.href || location.pathname.startsWith(item.href + '/');
    return (
      <NavLink
        key={item.href}
        to={item.href}
        title={item.label}
        className={`sidebar-nav-item group relative flex items-center gap-3 rounded-xl transition-all duration-200 ${
          isActive
            ? 'bg-[rgba(0,255,170,0.05)] text-[#E6F5ED] font-semibold'
            : 'text-[#4D6E5F] hover:text-[#8FAEA0] hover:bg-[#0B1210]'
        }`}
        style={{
          padding: sidebarExpanded ? '8px 12px' : '8px',
          justifyContent: sidebarExpanded ? 'flex-start' : 'center',
        }}
      >
        {/* Active accent bar */}
        {isActive && (
          <div className="absolute left-0 top-[20%] bottom-[20%] w-[3px] rounded-r-full bg-brand" />
        )}
        <item.icon
          className={`w-[18px] h-[18px] shrink-0 transition-colors ${isActive ? 'text-brand' : ''}`}
          strokeWidth={1.5}
        />
        {sidebarExpanded && (
          <>
            <span className="text-xs whitespace-nowrap overflow-hidden">{item.label}</span>
            {item.badge && (
              <span className="ml-auto px-1.5 py-0.5 rounded-md text-[9px] font-bold bg-[rgba(167,139,250,0.1)] text-[#A78BFA]">
                {item.badge}
              </span>
            )}
          </>
        )}
      </NavLink>
    );
  };

  return (
    <div className="flex h-screen bg-bg overflow-hidden">
      {/* ═══ SIDEBAR ═══ */}
      <aside
        className="sidebar-shell flex-shrink-0 flex flex-col bg-[#060908] border-r border-border-subtle"
        style={{ width: sidebarExpanded ? 240 : 64, transition: 'width 0.25s cubic-bezier(0.4, 0, 0.2, 1)' }}
        onMouseEnter={() => setSidebarExpanded(true)}
        onMouseLeave={() => {
          setSidebarExpanded(false);
          setMenuOpen(false);
        }}
      >
        {/* Logo */}
        <div
          className="flex items-center gap-3 border-b border-border-subtle overflow-hidden"
          style={{
            padding: sidebarExpanded ? '14px 16px' : '14px 0',
            justifyContent: sidebarExpanded ? 'flex-start' : 'center',
          }}
        >
          <div className="w-9 h-9 rounded-xl bg-brand flex items-center justify-center shrink-0">
            <Zap className="w-[18px] h-[18px] text-bg" strokeWidth={2.5} />
          </div>
          {sidebarExpanded && (
            <div className="min-w-0">
              <div className="text-sm font-extrabold text-text-primary tracking-tight leading-tight">
                OmniFlow
              </div>
              <div className="text-2xs text-text-muted">AI chatbot builder</div>
            </div>
          )}
        </div>

        {/* AI status */}
        <div className="overflow-hidden" style={{ padding: sidebarExpanded ? '8px 8px 0' : '8px 8px 0' }}>
          <div
            className="rounded-lg border border-border-glow bg-brand-soft flex items-center gap-1.5 overflow-hidden"
            style={{
              padding: sidebarExpanded ? '6px 10px' : '6px',
              justifyContent: sidebarExpanded ? 'flex-start' : 'center',
            }}
          >
            <div className="w-[5px] h-[5px] rounded-full bg-brand shrink-0 animate-pulse" />
            {sidebarExpanded ? (
              <>
                <span className="text-2xs font-semibold text-brand whitespace-nowrap">Claude 4 Sonnet</span>
                <span className="ml-auto text-2xs text-text-muted">online</span>
              </>
            ) : null}
          </div>
        </div>

        {/* Navigation */}
        <nav
          className="flex-1 overflow-y-auto overflow-x-hidden py-2"
          style={{ padding: sidebarExpanded ? '8px 8px' : '8px 6px' }}
        >
          {sidebarExpanded && (
            <div className="text-[9px] font-bold text-text-muted uppercase tracking-[1.5px] px-3 pt-2 pb-1.5">
              Build
            </div>
          )}
          {!sidebarExpanded && <div className="w-6 h-px bg-border-subtle mx-auto mb-2 mt-1" />}
          <div className="flex flex-col gap-0.5">{buildNav.map(renderNavItem)}</div>

          {sidebarExpanded && (
            <div className="text-[9px] font-bold text-text-muted uppercase tracking-[1.5px] px-3 pt-4 pb-1.5">
              Configure
            </div>
          )}
          {!sidebarExpanded && <div className="w-6 h-px bg-border-subtle mx-auto my-2" />}
          <div className="flex flex-col gap-0.5">{configureNav.map(renderNavItem)}</div>

          {sidebarExpanded && (
            <div className="text-[9px] font-bold text-text-muted uppercase tracking-[1.5px] px-3 pt-4 pb-1.5">
              System
            </div>
          )}
          {!sidebarExpanded && <div className="w-6 h-px bg-border-subtle mx-auto my-2" />}
          <div className="flex flex-col gap-0.5">{settingsNav.map(renderNavItem)}</div>
        </nav>

        {/* User */}
        <div
          className="border-t border-border-subtle"
          ref={menuRef}
          style={{ padding: sidebarExpanded ? '8px' : '8px 6px' }}
        >
          <div className="relative">
            <button
              onClick={() => setMenuOpen(!menuOpen)}
              className="w-full flex items-center gap-2.5 rounded-xl bg-bg-elevated border border-border-subtle hover:border-border-medium transition-all overflow-hidden"
              style={{
                padding: sidebarExpanded ? '8px 10px' : '8px',
                justifyContent: sidebarExpanded ? 'flex-start' : 'center',
              }}
            >
              <div className="w-8 h-8 rounded-lg bg-[#132A21] flex items-center justify-center text-2xs font-extrabold text-[#8FAEA0] shrink-0">
                {initials}
              </div>
              {sidebarExpanded && (
                <>
                  <div className="flex-1 text-left min-w-0">
                    <div className="text-2xs font-bold text-text-primary truncate">{displayName}</div>
                    <div className="text-[9px] text-text-muted truncate">{displayRole}</div>
                  </div>
                  <ChevronDown
                    className={`w-3 h-3 text-text-muted shrink-0 transition-transform duration-200 ${menuOpen ? 'rotate-180' : ''}`}
                  />
                </>
              )}
            </button>

            {menuOpen && sidebarExpanded && (
              <div className="absolute bottom-full left-0 right-0 mb-2 bg-bg-card border border-border-subtle rounded-xl overflow-hidden z-50 shadow-[0_8px_32px_rgba(0,0,0,0.5)]">
                <div className="px-4 py-3 border-b border-border-subtle">
                  <div className="text-sm font-bold text-text-primary">{displayName}</div>
                  <div className="text-xs text-text-muted mt-0.5">{displayEmail}</div>
                </div>
                <div className="py-1">
                  <button
                    onClick={() => {
                      setMenuOpen(false);
                      navigate('/dashboard/settings');
                    }}
                    className="w-full flex items-center gap-3 px-4 py-2.5 text-sm text-text-secondary hover:text-text-primary hover:bg-bg-elevated transition-all"
                  >
                    <User className="w-4 h-4" strokeWidth={1.6} /> Account settings
                  </button>
                </div>
                <div className="border-t border-border-subtle py-1">
                  <button
                    onClick={() => {
                      setMenuOpen(false);
                      logout.mutate();
                    }}
                    className="w-full flex items-center gap-3 px-4 py-2.5 text-sm text-danger hover:bg-danger-soft transition-all"
                  >
                    <LogOut className="w-4 h-4" strokeWidth={1.6} />
                    {logout.isPending ? 'Logging out...' : 'Log out'}
                  </button>
                </div>
              </div>
            )}
          </div>
        </div>
      </aside>

      {/* ═══ MAIN CONTENT ═══ */}
      <main className="flex-1 flex flex-col overflow-hidden">
        {/* Header */}
        <header className="bg-[#080A09] border-b border-border-subtle px-6 h-14 flex items-center gap-3 flex-shrink-0">
          <div className="w-7 h-7 rounded-lg bg-brand-soft border border-border-glow flex items-center justify-center shrink-0">
            <PageIcon className="w-3.5 h-3.5 text-brand" strokeWidth={1.5} />
          </div>
          <h1 className="text-[15px] font-extrabold text-text-primary tracking-tight">{getPageTitle()}</h1>
          <div className="ml-auto flex items-center gap-2">
            <button
              onClick={() => navigate(ROUTES.dashboard.flows)}
              className="px-4 py-2 rounded-xl text-xs font-semibold border border-border-subtle text-text-secondary hover:text-text-primary hover:border-border-medium hover:bg-bg-elevated transition-all flex items-center gap-1.5"
            >
              <Bot className="w-3.5 h-3.5" strokeWidth={1.8} /> AI Builder
            </button>
            <button className="px-4 py-2 rounded-xl text-xs font-bold text-bg bg-brand hover:bg-brand-light transition-all flex items-center gap-1.5">
              <Zap className="w-3.5 h-3.5" strokeWidth={2} /> Deploy
            </button>
          </div>
        </header>

        {/* Page Content */}
        <div className="flex-1 overflow-auto p-6">
          <Outlet />
        </div>
      </main>
    </div>
  );
}
