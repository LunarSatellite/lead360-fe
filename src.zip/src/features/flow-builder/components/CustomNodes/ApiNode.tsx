import { memo } from 'react';
import { Handle, Position } from '@xyflow/react';
import type { FlowNodeData } from '../../types/flow.types';
function Inner({ data }: { data: FlowNodeData }) {
  const method = (data.config as Record<string, string>)?.method || 'GET';
  return (
    <div className="w-[180px] bg-bg-card rounded-xl border-2 border-cyan-700 hover:brightness-110 transition-shadow">
      <Handle
        type="target"
        position={Position.Top}
        className="!w-3 !h-3 !bg-cyan-500 !border-2 !border-bg-card"
      />
      <div className="flex items-center gap-2 px-3 py-2.5 border-b border-cyan-800">
        <div className="w-6 h-6 rounded-md bg-cyan-950 flex items-center justify-center text-xs">🔌</div>
        <span className="text-xs font-semibold text-text-primary truncate flex-1">{data.label}</span>
      </div>
      <div className="px-3 py-2">
        <span className="px-1.5 py-0.5 rounded bg-cyan-950 text-cyan-400 text-[10px] font-medium">
          {method}
        </span>
      </div>
      <Handle
        type="source"
        position={Position.Bottom}
        className="!w-3 !h-3 !bg-cyan-500 !border-2 !border-bg-card"
      />
    </div>
  );
}
export const ApiNode = memo(Inner);
