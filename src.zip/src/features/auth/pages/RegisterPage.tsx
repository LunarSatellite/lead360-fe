import { useState, useMemo } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { Eye, EyeOff, Check, X, ShieldCheck, Info } from 'lucide-react';
import { registerSchema, type RegisterFormData } from '../types/auth.schemas';
import { useRegister } from '../api/auth.queries';
import { BusinessType, BUSINESS_TYPE_LABEL } from '../types/auth.types';
import { useComplianceProfiles } from '@/features/compliance/api/compliance.queries';
import type { ComplianceProfileSummary } from '@/features/compliance/types/compliance.types';

export function Component() {
  const navigate = useNavigate();
  const register = useRegister();
  const [showPw, setShowPw] = useState(false);

  const { data: profilesRaw, isLoading: profilesLoading } = useComplianceProfiles();
  const profiles = (profilesRaw as unknown as ComplianceProfileSummary[]) || [];

  const industryOptions = useMemo(() => {
    const fromProfiles = profiles.map((p) => ({
      value: p.industry ?? '',
      label: p.name ?? p.industry ?? 'Unknown',
      ruleCount: p.ruleCount,
      profileId: p.id,
      requiresAgeVerification: p.requiresAgeVerification,
    }));
    if (!fromProfiles.some((o) => o.value === 'General')) {
      fromProfiles.push({
        value: 'Other',
        label: 'Other',
        ruleCount: 0,
        profileId: '',
        requiresAgeVerification: false,
      });
    }
    return fromProfiles;
  }, [profiles]);

  const form = useForm<RegisterFormData>({
    resolver: zodResolver(registerSchema),
    defaultValues: {
      businessName: '',
      businessType: BusinessType.Goods,
      industry: '',
      businessDescription: '',
      firstName: '',
      lastName: '',
      email: '',
      password: '',
      phone: '',
    },
    mode: 'onChange',
  });

  const pw = form.watch('password');
  const watchedIndustry = form.watch('industry');

  const matchedProfile = useMemo(() => {
    if (!watchedIndustry) return null;
    return industryOptions.find((o) => o.value === watchedIndustry) ?? null;
  }, [watchedIndustry, industryOptions]);

  const pwChecks = [
    { label: '8+ characters', pass: pw.length >= 8 },
    { label: 'Uppercase', pass: /[A-Z]/.test(pw) },
    { label: 'Lowercase', pass: /[a-z]/.test(pw) },
    { label: 'Digit', pass: /[0-9]/.test(pw) },
  ];

  const onSubmit = (data: RegisterFormData) => {
    register.mutate(
      {
        ...data,
        businessDescription: data.businessDescription || undefined,
        phone: data.phone || undefined,
      } as any,
      { onSuccess: () => navigate('/auth/login') },
    );
  };

  /* ── Shared input classes (matching LoginPage exactly) ── */
  const inputCls =
    'w-full px-4 py-3 rounded-xl bg-bg-input border border-border-subtle text-base text-text-primary placeholder:text-text-muted focus:outline-none focus:border-brand focus:shadow-[0_0_0_3px_rgba(0,217,126,0.1)] transition-all';
  const selectCls =
    'w-full px-4 py-3 rounded-xl bg-bg-input border border-border-subtle text-base text-text-primary focus:outline-none focus:border-brand focus:shadow-[0_0_0_3px_rgba(0,217,126,0.1)] transition-all appearance-none cursor-pointer';

  return (
    <div className="space-y-6">
      {/* Header */}
      <div>
        <h1 className="text-3xl font-extrabold text-text-primary tracking-tight">Create your account</h1>
        <p className="text-base text-text-secondary mt-2">Set up your business and start building</p>
      </div>

      {/* Google signup */}
      <button
        type="button"
        className="w-full flex items-center justify-center gap-3 py-3 rounded-xl border border-border-subtle bg-bg-card text-sm font-semibold text-text-primary hover:bg-bg-elevated transition-all"
      >
        <svg className="w-5 h-5" viewBox="0 0 24 24">
          <path
            d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92a5.06 5.06 0 01-2.2 3.32v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.1z"
            fill="#4285F4"
          />
          <path
            d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"
            fill="#34A853"
          />
          <path
            d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18A10.96 10.96 0 001 12c0 1.77.42 3.45 1.18 4.93l3.66-2.84z"
            fill="#FBBC05"
          />
          <path
            d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z"
            fill="#EA4335"
          />
        </svg>
        Continue with Google
      </button>

      {/* Divider */}
      <div className="flex items-center gap-4">
        <div className="flex-1 h-px bg-border-subtle" />
        <span className="text-xs text-text-muted uppercase tracking-wider">or</span>
        <div className="flex-1 h-px bg-border-subtle" />
      </div>

      <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-5">
        {/* ── Section: Business ── */}
        <div className="flex items-center gap-3">
          <span className="text-xs font-bold uppercase tracking-[3px] text-brand">Business details</span>
          <div className="flex-1 h-px bg-border-subtle" />
        </div>

        <div>
          <label className="text-sm font-semibold text-text-primary block mb-2">Business name</label>
          <input {...form.register('businessName')} placeholder="e.g. MYDAWA Pharmacy" className={inputCls} />
          {form.formState.errors.businessName && (
            <p className="text-xs text-danger mt-1.5">{form.formState.errors.businessName.message}</p>
          )}
        </div>

        <div className="grid grid-cols-2 gap-4">
          <div>
            <label className="text-sm font-semibold text-text-primary block mb-2">Business type</label>
            <select {...form.register('businessType', { valueAsNumber: true })} className={selectCls}>
              {Object.entries(BusinessType).map(([_key, val]) => (
                <option key={val} value={val} className="bg-bg-input text-text-primary">
                  {BUSINESS_TYPE_LABEL[val]}
                </option>
              ))}
            </select>
            {form.formState.errors.businessType && (
              <p className="text-xs text-danger mt-1.5">{form.formState.errors.businessType.message}</p>
            )}
          </div>
          <div>
            <label className="text-sm font-semibold text-text-primary block mb-2">Industry</label>
            <select {...form.register('industry')} className={selectCls}>
              <option value="" className="bg-bg-input text-text-muted">
                {profilesLoading ? 'Loading...' : 'Select industry'}
              </option>
              {industryOptions.map((opt) => (
                <option key={opt.value} value={opt.value} className="bg-bg-input text-text-primary">
                  {opt.label}
                </option>
              ))}
            </select>
            {form.formState.errors.industry && (
              <p className="text-xs text-danger mt-1.5">{form.formState.errors.industry.message}</p>
            )}
          </div>
        </div>

        {/* Compliance profile info */}
        {matchedProfile && matchedProfile.ruleCount > 0 && (
          <div className="px-4 py-3 rounded-xl bg-info-soft border border-[rgba(59,130,246,0.12)]">
            <div className="flex items-start gap-2.5">
              <Info className="w-4 h-4 text-info shrink-0 mt-0.5" strokeWidth={1.6} />
              <div className="flex-1">
                <div className="flex items-center gap-1.5">
                  <ShieldCheck className="w-3.5 h-3.5 text-brand" strokeWidth={1.6} />
                  <span className="text-sm font-bold text-text-primary">
                    Compliance: {matchedProfile.label}
                  </span>
                </div>
                <p className="text-xs text-text-secondary mt-1 leading-relaxed">
                  Your chatbot will follow {matchedProfile.label.toLowerCase()} compliance rules including{' '}
                  {matchedProfile.ruleCount} rules covering prohibited topics, required disclaimers, and
                  restricted phrases.
                </p>
                {matchedProfile.requiresAgeVerification && (
                  <p className="text-xs text-warning font-semibold mt-1.5">
                    This profile requires age verification for customers.
                  </p>
                )}
                <p className="text-[10px] font-semibold text-text-muted mt-1.5 uppercase tracking-wider">
                  You can customize this later in Settings
                </p>
              </div>
            </div>
          </div>
        )}

        <div>
          <label className="text-sm font-semibold text-text-primary block mb-2">
            Business description <span className="text-text-muted font-normal">(optional)</span>
          </label>
          <textarea
            {...form.register('businessDescription')}
            placeholder="Briefly describe what your business does..."
            rows={2}
            className={`${inputCls} resize-none`}
          />
        </div>

        {/* ── Section: Account ── */}
        <div className="flex items-center gap-3 pt-2">
          <span className="text-xs font-bold uppercase tracking-[3px] text-brand">Your account</span>
          <div className="flex-1 h-px bg-border-subtle" />
        </div>

        <div className="grid grid-cols-2 gap-4">
          <div>
            <label className="text-sm font-semibold text-text-primary block mb-2">First name</label>
            <input
              {...form.register('firstName')}
              placeholder="John"
              autoComplete="given-name"
              className={inputCls}
            />
            {form.formState.errors.firstName && (
              <p className="text-xs text-danger mt-1.5">{form.formState.errors.firstName.message}</p>
            )}
          </div>
          <div>
            <label className="text-sm font-semibold text-text-primary block mb-2">Last name</label>
            <input
              {...form.register('lastName')}
              placeholder="Doe"
              autoComplete="family-name"
              className={inputCls}
            />
            {form.formState.errors.lastName && (
              <p className="text-xs text-danger mt-1.5">{form.formState.errors.lastName.message}</p>
            )}
          </div>
        </div>

        <div>
          <label className="text-sm font-semibold text-text-primary block mb-2">Email</label>
          <input
            {...form.register('email')}
            type="email"
            placeholder="you@company.com"
            autoComplete="email"
            className={inputCls}
          />
          {form.formState.errors.email && (
            <p className="text-xs text-danger mt-1.5">{form.formState.errors.email.message}</p>
          )}
        </div>

        <div>
          <label className="text-sm font-semibold text-text-primary block mb-2">Password</label>
          <div className="relative">
            <input
              {...form.register('password')}
              type={showPw ? 'text' : 'password'}
              placeholder="Min 8 characters"
              autoComplete="new-password"
              className={`${inputCls} pr-12`}
            />
            <button
              type="button"
              onClick={() => setShowPw(!showPw)}
              className="absolute right-4 top-1/2 -translate-y-1/2 text-text-muted hover:text-text-secondary transition-colors"
            >
              {showPw ? <EyeOff className="w-5 h-5" /> : <Eye className="w-5 h-5" />}
            </button>
          </div>
          {pw.length > 0 && (
            <div className="mt-3 grid grid-cols-2 gap-x-4 gap-y-2">
              {pwChecks.map((c) => (
                <div key={c.label} className="flex items-center gap-2">
                  {c.pass ? (
                    <div className="w-4 h-4 rounded-full bg-brand/20 flex items-center justify-center">
                      <Check className="w-3 h-3 text-brand" strokeWidth={3} />
                    </div>
                  ) : (
                    <div className="w-4 h-4 rounded-full bg-border-subtle flex items-center justify-center">
                      <X className="w-3 h-3 text-text-muted" strokeWidth={2} />
                    </div>
                  )}
                  <span className={`text-xs font-medium ${c.pass ? 'text-brand' : 'text-text-muted'}`}>
                    {c.label}
                  </span>
                </div>
              ))}
            </div>
          )}
        </div>

        <div>
          <label className="text-sm font-semibold text-text-primary block mb-2">
            Phone <span className="text-text-muted font-normal">(optional)</span>
          </label>
          <input
            {...form.register('phone')}
            type="tel"
            placeholder="+254 712 345 678"
            autoComplete="tel"
            className={inputCls}
          />
        </div>

        {/* Error */}
        {register.isError && (
          <div className="px-4 py-3 rounded-xl bg-danger-soft border border-[rgba(244,63,94,0.15)] text-sm text-danger">
            {register.error?.message || 'Registration failed.'}
          </div>
        )}

        {/* Submit */}
        <button
          type="submit"
          disabled={register.isPending}
          className="w-full flex items-center justify-center gap-2.5 py-3.5 rounded-xl text-bg text-base font-bold bg-brand hover:bg-brand-light disabled:opacity-50 transition-all"
        >
          {register.isPending && (
            <span className="w-5 h-5 border-2 border-bg/30 border-t-bg rounded-full animate-spin" />
          )}
          {register.isPending ? 'Creating...' : 'Create account'}
        </button>
      </form>

      {/* Terms */}
      <p className="text-center text-xs text-text-muted leading-relaxed">
        By creating an account, you agree to the{' '}
        <span className="text-brand font-semibold cursor-pointer hover:text-brand-light transition-colors">
          Terms
        </span>{' '}
        and{' '}
        <span className="text-brand font-semibold cursor-pointer hover:text-brand-light transition-colors">
          Privacy Policy
        </span>
      </p>

      <p className="text-center text-sm text-text-muted">
        Already have an account?{' '}
        <Link to="/auth/login" className="text-brand font-semibold hover:text-brand-light transition-colors">
          Sign in
        </Link>
      </p>
    </div>
  );
}
