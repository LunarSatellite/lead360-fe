import { useState, useRef, useEffect } from 'react';
import { Loader2, Send } from 'lucide-react';
import { useChatModifyFlow } from '../api/flow.queries';
import type { FlowDto, LlmConversationEntry } from '../types/flow.types';

interface AiChatPanelProps {
  flowId: string | null;
  llmConversationJson: string | null;
  onFlowUpdated: (flow: FlowDto) => void;
}

interface ChatMsg {
  role: 'user' | 'assistant';
  content: string;
}

export function AiChatPanel({ flowId, llmConversationJson, onFlowUpdated }: AiChatPanelProps) {
  const [input, setInput] = useState('');
  const chatEndRef = useRef<HTMLDivElement>(null);
  const chatModify = useChatModifyFlow();

  // Parse conversation history from backend
  const history: ChatMsg[] = (() => {
    if (!llmConversationJson) return [];
    try {
      const parsed = JSON.parse(llmConversationJson) as LlmConversationEntry[];
      return parsed.map((e) => ({ role: e.role === 'user' ? 'user' as const : 'assistant' as const, content: e.content }));
    } catch {
      return [];
    }
  })();

  const [localMsgs, setLocalMsgs] = useState<ChatMsg[]>([
    { role: 'assistant', content: '👋 Hi! I can modify your flow. Try:\n• "Add error handling"\n• "Add a welcome message"\n• "Route complaints to agents"' },
  ]);

  // Merge backend history + local
  const allMessages = [...history, ...localMsgs];

  useEffect(() => {
    chatEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [allMessages.length]);

  const handleSend = () => {
    if (!input.trim() || !flowId || chatModify.isPending) return;
    const msg = input.trim();
    setLocalMsgs((p) => [...p, { role: 'user', content: msg }]);
    setInput('');

    chatModify.mutate(
      { id: flowId, data: { Message: msg } },
      {
        onSuccess: (flow) => {
          setLocalMsgs((p) => [
            ...p,
            {
              role: 'assistant',
              content: `✅ Flow updated to v${flow.version} (${flow.nodeCount} nodes, ${flow.connectionCount} connections)`,
            },
          ]);
          onFlowUpdated(flow);
        },
        onError: () => {
          setLocalMsgs((p) => [
            ...p,
            { role: 'assistant', content: '❌ Sorry, I couldn\'t process that. Try rephrasing.' },
          ]);
        },
      },
    );
  };

  return (
    <div className="flex flex-col h-full">
      {/* Messages */}
      <div className="flex-1 overflow-auto px-3 py-2">
        {allMessages.map((m, i) => (
          <div key={i} className={`mb-2 ${m.role === 'user' ? 'text-right' : ''}`}>
            <div
              className="inline-block max-w-[90%] px-3 py-2 text-2xs leading-relaxed whitespace-pre-wrap"
              style={{
                borderRadius: 10,
                ...(m.role === 'user'
                  ? {
                      background: 'linear-gradient(135deg,#059669,#10B981)',
                      color: '#fff',
                      borderBottomRightRadius: 3,
                    }
                  : { background: '#F1F5F9', color: '#475569', borderBottomLeftRadius: 3 }),
              }}
            >
              {m.content}
            </div>
          </div>
        ))}

        {chatModify.isPending && (
          <div className="mb-2">
            <div
              className="inline-block px-3 py-2 text-2xs rounded-[10px]"
              style={{
                background: 'linear-gradient(90deg,#F3E8FF,#FCE7F3,#F3E8FF)',
                backgroundSize: '200% 100%',
                animation: 'shimmer 2s linear infinite',
              }}
            >
              <div className="flex items-center gap-1.5">
                <span className="text-xs">🧠</span>
                <span className="text-[#7C3AED] font-semibold">Modifying flow...</span>
              </div>
            </div>
          </div>
        )}
        <div ref={chatEndRef} />
      </div>

      {/* Input */}
      <div className="flex gap-1.5 p-2.5 border-t border-border-subtle">
        <input
          value={input}
          onChange={(e) => setInput(e.target.value)}
          onKeyDown={(e) => e.key === 'Enter' && handleSend()}
          placeholder={flowId ? 'Ask AI to modify...' : 'Generate a flow first'}
          disabled={!flowId || chatModify.isPending}
          className="flex-1 px-2.5 py-2 rounded-lg bg-glass-1 border border-border-subtle text-2xs text-text-primary outline-none focus:border-brand disabled:opacity-50"
        />
        <button
          onClick={handleSend}
          disabled={!flowId || !input.trim() || chatModify.isPending}
          className="px-3 py-2 rounded-lg text-2xs font-semibold text-white border-none cursor-pointer disabled:opacity-40 flex items-center gap-1"
          style={{ background: '#059669' }}
        >
          {chatModify.isPending ? <Loader2 className="w-3 h-3 animate-spin" /> : <Send className="w-3 h-3" />}
        </button>
      </div>
    </div>
  );
}
