import { useState, useCallback } from 'react';
import { Send, Loader2 } from 'lucide-react';
import { WhatsAppPreview } from './WhatsAppPreview';
import { TelegramPreview } from './TelegramPreview';
import { WebChatPreview } from './WebChatPreview';
import { SmsPreview } from './SmsPreview';
import { useFlowRuntimeMessage } from '../../api/flow.queries';
import type { FlowMenuItemDto } from '../../types/flow-runtime.types';

interface PreviewMessage {
  role: 'user' | 'bot';
  text: string;
  buttons?: { label: string; value: string }[];
}

const CHANNELS = ['WhatsApp', 'Telegram', 'WebChat', 'SMS'] as const;

export function LivePreview() {
  const [input, setInput] = useState('');
  const [sessionId] = useState(() => crypto.randomUUID());
  const [channelMessages, setChannelMessages] = useState<Record<string, PreviewMessage[]>>({
    WhatsApp: [], Telegram: [], WebChat: [], SMS: [],
  });

  const flowMessage = useFlowRuntimeMessage();

  const sendMessage = useCallback(
    (text: string) => {
      if (!text.trim() || flowMessage.isPending) return;
      const msg = text.trim();

      // Add user message to all channels
      setChannelMessages((prev) => {
        const next = { ...prev };
        for (const ch of CHANNELS) {
          next[ch] = [...(next[ch] || []), { role: 'user' as const, text: msg }];
        }
        return next;
      });
      setInput('');

      // Single call to flow-runtime — menuItems included in response
      flowMessage.mutate(
        { SessionId: sessionId, Message: msg },
        {
          onSuccess: (res) => {
            const buttons = (res.menuItems || []).map((item: FlowMenuItemDto) => ({
              label: item.label,
              value: item.value,
            }));

            // Add bot response to all channels
            CHANNELS.forEach((ch) => {
              setChannelMessages((prev) => ({
                ...prev,
                [ch]: [
                  ...(prev[ch] || []),
                  { role: 'bot' as const, text: res.response || 'No response', buttons: buttons.length > 0 ? buttons : undefined },
                ],
              }));
            });
          },
          onError: () => {
            CHANNELS.forEach((ch) => {
              setChannelMessages((prev) => ({
                ...prev,
                [ch]: [...(prev[ch] || []), { role: 'bot' as const, text: '❌ Execution error' }],
              }));
            });
          },
        },
      );
    },
    [flowMessage, sessionId],
  );

  const handleButtonClick = useCallback(
    (value: string) => {
      sendMessage(value);
    },
    [sendMessage],
  );

  return (
    <div className="flex flex-col h-full">
      {/* Channel Previews Grid */}
      <div className="flex-1 grid grid-cols-4 gap-2 p-3 overflow-hidden">
        {CHANNELS.map((ch) => (
          <div key={ch} className="flex flex-col rounded-xl overflow-hidden border border-border-subtle bg-white min-h-0">
            <div className="text-center text-[10px] font-bold uppercase tracking-wider py-1 bg-glass-1 text-text-muted border-b border-border-subtle">
              {ch}
            </div>
            <div className="flex-1 overflow-hidden">
              {ch === 'WhatsApp' && <WhatsAppPreview messages={channelMessages.WhatsApp || []} onButtonClick={handleButtonClick} />}
              {ch === 'Telegram' && <TelegramPreview messages={channelMessages.Telegram || []} onButtonClick={handleButtonClick} />}
              {ch === 'WebChat' && <WebChatPreview messages={channelMessages.WebChat || []} onButtonClick={handleButtonClick} />}
              {ch === 'SMS' && <SmsPreview messages={channelMessages.SMS || []} onButtonClick={handleButtonClick} />}
            </div>
          </div>
        ))}
      </div>

      {/* Shared Input */}
      <div className="flex gap-2 px-4 py-3 border-t border-border-subtle bg-white">
        <input
          value={input}
          onChange={(e) => setInput(e.target.value)}
          onKeyDown={(e) => e.key === 'Enter' && sendMessage(input)}
          placeholder="Type a message (sends to all channels)..."
          className="flex-1 px-3 py-2 border border-border-subtle rounded-lg text-sm outline-none focus:border-brand"
        />
        <button
          onClick={() => sendMessage(input)}
          disabled={!input.trim() || flowMessage.isPending}
          className="px-4 py-2 rounded-lg text-sm font-semibold text-white disabled:opacity-40 flex items-center gap-1.5"
          style={{ background: 'linear-gradient(135deg,#059669,#10B981)' }}
        >
          {flowMessage.isPending ? <Loader2 className="w-4 h-4 animate-spin" /> : <Send className="w-4 h-4" />}
          Send
        </button>
      </div>
    </div>
  );
}
