import { User, Package, Search, AlertTriangle, List } from 'lucide-react';
import type { ScenarioPreset } from '../types/test-channel.types';

const PRESETS: ScenarioPreset[] = [
  {
    label: 'New Customer',
    description: 'Fresh session, sends greeting',
    messages: ['Hi'],
    icon: 'User',
    color: 'success',
  },
  {
    label: 'Track Order',
    description: 'Sends "track my order"',
    messages: ['track my order'],
    icon: 'Package',
    color: 'brand',
  },
  {
    label: 'Product Search',
    description: 'Natural language product query',
    messages: ['I need headache medicine'],
    icon: 'Search',
    color: 'info',
  },
  {
    label: 'Agent Handoff',
    description: 'Triggers escalation',
    messages: ['asdfghjkl', 'this makes no sense', 'talk to a person'],
    icon: 'AlertTriangle',
    color: 'danger',
  },
  {
    label: 'Menu Navigation',
    description: 'Walks menu with numbered replies',
    messages: ['1', '2', '1'],
    icon: 'List',
    color: 'warning',
  },
];

const ICON_MAP: Record<string, typeof User> = {
  User,
  Package,
  Search,
  AlertTriangle,
  List,
};

const COLOR_MAP: Record<string, { bg: string; text: string; border: string }> = {
  success: { bg: 'bg-success-soft', text: 'text-success', border: 'border-[rgba(6,214,160,0.15)]' },
  brand: { bg: 'bg-brand-soft', text: 'text-brand', border: 'border-brand' },
  info: { bg: 'bg-info-soft', text: 'text-info', border: 'border-[rgba(59,130,246,0.12)]' },
  warning: { bg: 'bg-warning-soft', text: 'text-warning', border: 'border-[rgba(245,158,11,0.12)]' },
  danger: { bg: 'bg-danger-soft', text: 'text-danger', border: 'border-[rgba(244,63,94,0.12)]' },
};

interface ScenarioPresetsProps {
  onRun: (messages: string[]) => void;
  disabled?: boolean;
}

export function ScenarioPresets({ onRun, disabled }: ScenarioPresetsProps) {
  return (
    <div className="p-3 space-y-2">
      <div className="text-[9px] font-bold uppercase tracking-[2px] text-text-muted mb-2">
        Test scenarios
      </div>
      {PRESETS.map((preset) => {
        const Icon = ICON_MAP[preset.icon] ?? User;
        const color = COLOR_MAP[preset.color];
        return (
          <button
            key={preset.label}
            onClick={() => onRun(preset.messages)}
            disabled={disabled}
            className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-lg border transition-all duration-150
                       hover:bg-glass-2 hover:border-border-medium disabled:opacity-40 disabled:cursor-not-allowed
                       bg-glass-1 border-border-subtle text-left`}
          >
            <div className={`w-8 h-8 rounded-lg ${color.bg} ${color.border} border flex items-center justify-center flex-shrink-0`}>
              <Icon className={`w-4 h-4 ${color.text}`} strokeWidth={1.6} />
            </div>
            <div className="flex-1 min-w-0">
              <div className="text-xs font-bold text-text-primary">{preset.label}</div>
              <div className="text-[10px] text-text-muted">{preset.description}</div>
            </div>
            <div className="text-[9px] font-semibold text-text-muted flex-shrink-0">
              {preset.messages.length} msg{preset.messages.length > 1 ? 's' : ''}
            </div>
          </button>
        );
      })}
    </div>
  );
}
