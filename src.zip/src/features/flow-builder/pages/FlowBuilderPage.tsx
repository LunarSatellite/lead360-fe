import { useState, useCallback, useRef, useEffect, useMemo } from 'react';
import {
  ReactFlowProvider,
  ReactFlow,
  Background,
  Controls,
  MiniMap,
  type Node,
  useReactFlow,
} from '@xyflow/react';
import '@xyflow/react/dist/style.css';
import {
  Loader2,
  Send,
  Save,
  Rocket,
  Trash2,
  Copy,
  Undo2,
  Redo2,
  FolderOpen,
  X,
  Check,
  Pencil,
} from 'lucide-react';
import {
  useFlows,
  useFlowById,
  useGenerateFlow,
  useChatModifyFlow,
  useActivateFlow,
  useDuplicateFlow,
  useDeleteFlow,
  useFlowRuntimeMessage,
} from '../api/flow.queries';
import { useFlowEditor } from '../hooks/useFlowEditor';
import { useChannels } from '@/features/channels/api/channels.queries';
import { CHANNEL_TYPE_LABEL, type ChannelConnectionDto } from '@/features/channels/types/channels.types';
import { TriggerNode } from '../components/CustomNodes/TriggerNode';
import { AiNode } from '../components/CustomNodes/AiNode';
import { ConditionNode } from '../components/CustomNodes/ConditionNode';
import { ResponseNode } from '../components/CustomNodes/ResponseNode';
import { ApiNode } from '../components/CustomNodes/ApiNode';
import { ActionNode } from '../components/CustomNodes/ActionNode';
import { FlowSimulator } from '../components/FlowSimulator';
import {
  NODE_TYPE_META,
  FLOW_STATUS_LABEL,
  type FlowDto,
  type FlowNodeData,
  type FlowNodeTypeValue,
} from '../types/flow.types';
import { type FlowRuntimeResult, type FlowMenuItemDto } from '../types/flow-runtime.types';

const nodeTypes = {
  trigger: TriggerNode,
  ai: AiNode,
  condition: ConditionNode,
  response: ResponseNode,
  api: ApiNode,
  action: ActionNode,
};

const HINTS = [
  'Build order tracking flow',
  'Product menu with categories',
  'Customer support with sentiment',
  'Complaint handling flow',
];
const STEPS = [
  'Analyzing...',
  'Identifying paths...',
  'Designing architecture...',
  'Creating nodes...',
  'Connecting...',
];
const PAL = Object.entries(NODE_TYPE_META).map(([k, v]) => ({ type: k as FlowNodeTypeValue, ...v }));

/* ═══════════════════════════════════════════════════════════════
   FLOW BUILDER — INNER (needs ReactFlowProvider)
   ═══════════════════════════════════════════════════════════════ */
function FlowBuilderInner() {
  const { data: flowsRaw, isLoading } = useFlows();
  const flows = useMemo(() => (flowsRaw as unknown as FlowDto[]) ?? [], [flowsRaw]);
  const editor = useFlowEditor();
  const { data: loadedFlowRaw } = useFlowById(editor.flowId || undefined);
  const loadedFlow = loadedFlowRaw as unknown as FlowDto | undefined;

  // When full flow is fetched by ID (with nodes+connections), push into editor
  // This handles: selecting from list (list items have no nodes), and page reload
  useEffect(() => {
    if (loadedFlow && loadedFlow.nodes && loadedFlow.nodes.length > 0 && loadedFlow.id === editor.flowId) {
      // Only re-set if editor currently has no nodes (was loaded from list without nodes)
      if (editor.nodes.length === 0) {
        editor.setFlow(loadedFlow);
      }
    }
  }, [loadedFlow]); // eslint-disable-line react-hooks/exhaustive-deps

  const generateFlow = useGenerateFlow();
  const chatModify = useChatModifyFlow();
  const activateFlow = useActivateFlow();
  const duplicateFlow = useDuplicateFlow();
  const deleteFlow = useDeleteFlow();

  const [nlpInput, setNlpInput] = useState('');
  const [thinkStep, setThinkStep] = useState(-1);
  const [chatInput, setChatInput] = useState('');
  const [chatMsgs, setChatMsgs] = useState<{ role: 'user' | 'bot'; text: string }[]>([
    {
      role: 'bot',
      text: '👋 Hi! Describe your bot above, or ask me to modify it.\n\nTry: "Add error handling", "Route complaints to agents"',
    },
  ]);
  const [tab, setTab] = useState<0 | 1 | 2>(0);
  const [sel, setSel] = useState<Node<FlowNodeData> | null>(null);
  const [showList, setShowList] = useState(false);
  const [showPreview, setShowPreview] = useState(false);
  const [editingName, setEditingName] = useState(false);
  const [simSession] = useState(() => crypto.randomUUID());

  const chatEndRef = useRef<HTMLDivElement>(null);
  const { screenToFlowPosition } = useReactFlow();
  const autoLoadedRef = useRef(false);

  // Auto-load active flow (or first flow) on page mount
  useEffect(() => {
    if (autoLoadedRef.current || flows.length === 0 || editor.flowId) return;
    autoLoadedRef.current = true;
    const active = flows.find((f) => f.isActive) || flows[0];
    if (active) {
      // Set flowId so useFlowById fires, then the effect above will push nodes into editor
      editor.setFlow(active);
    }
  }, [flows]); // eslint-disable-line react-hooks/exhaustive-deps

  useEffect(() => {
    chatEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [chatMsgs.length]);

  // ── NLP Generate ──
  const processNlp = useCallback(() => {
    if (!nlpInput.trim() || generateFlow.isPending) return;
    setThinkStep(0);
    const iv = setInterval(
      () =>
        setThinkStep((s) => {
          if (s >= STEPS.length - 1) {
            clearInterval(iv);
            return s;
          }
          return s + 1;
        }),
      800,
    );
    generateFlow.mutate(
      { Instruction: nlpInput.trim(), FlowName: nlpInput.trim().slice(0, 50) },
      {
        onSuccess: (f) => {
          clearInterval(iv);
          setThinkStep(-1);
          setNlpInput('');
          editor.setFlow(f);
          setSel(null);
          setChatMsgs((p) => [
            ...p,
            {
              role: 'bot',
              text: `✨ Built "${f.name}" (${f.nodeCount} nodes, ${f.connectionCount} connections)`,
            },
          ]);
        },
        onError: () => {
          clearInterval(iv);
          setThinkStep(-1);
        },
      },
    );
  }, [nlpInput, generateFlow, editor]);

  // ── AI Chat ──
  const sendChat = useCallback(() => {
    if (!chatInput.trim() || !editor.flowId || chatModify.isPending) return;
    const msg = chatInput.trim();
    setChatMsgs((p) => [...p, { role: 'user', text: msg }]);
    setChatInput('');
    chatModify.mutate(
      { id: editor.flowId, data: { Message: msg } },
      {
        onSuccess: (f) => {
          editor.setFlow(f);
          setSel(null);
          setChatMsgs((p) => [
            ...p,
            { role: 'bot', text: `✅ Updated to v${f.version} (${f.nodeCount} nodes)` },
          ]);
        },
        onError: () =>
          setChatMsgs((p) => [...p, { role: 'bot', text: "❌ Couldn't process that. Try rephrasing." }]),
      },
    );
  }, [chatInput, editor, chatModify]);

  // ── Canvas drop ──
  const onDragOver = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    e.dataTransfer.dropEffect = 'move';
  }, []);
  const onDrop = useCallback(
    (e: React.DragEvent) => {
      e.preventDefault();
      const type = e.dataTransfer.getData('application/reactflow-type') as FlowNodeTypeValue;
      if (!type || !NODE_TYPE_META[type]) return;
      const pos = screenToFlowPosition({ x: e.clientX, y: e.clientY });
      editor.addNode(type, `New ${NODE_TYPE_META[type].label}`, pos.x, pos.y);
    },
    [screenToFlowPosition, editor],
  );

  // ── Node config update ──
  const updateNodeData = useCallback(
    (nodeId: string, patch: Partial<FlowNodeData>) => {
      const newNodes = editor.nodes.map((n) =>
        n.id === nodeId ? { ...n, data: { ...n.data, ...patch } as FlowNodeData } : n,
      );
      editor.dispatch({ type: 'SNAPSHOT' });
      editor.dispatch({ type: 'SET_NODES', nodes: newNodes });
      if (sel?.id === nodeId)
        setSel((prev) => (prev ? { ...prev, data: { ...prev.data, ...patch } as FlowNodeData } : prev));
    },
    [editor, sel],
  );

  if (isLoading)
    return (
      <div className="flex items-center justify-center py-20">
        <Loader2 className="w-6 h-6 text-brand animate-spin" />
      </div>
    );

  /* ═══ PREVIEW MODE ═══ */
  if (showPreview)
    return (
      <div
        className="flex flex-col rounded-2xl border border-border-subtle bg-bg"
        style={{ height: 'calc(100vh - 180px)', minHeight: 500 }}
      >
        <div className="flex items-center justify-between px-4 py-2.5 border-b border-border-subtle flex-shrink-0">
          <h3 className="text-sm font-bold text-text-primary">📱 Multi-Channel Live Preview</h3>
          <button
            onClick={() => setShowPreview(false)}
            className="px-3 py-1.5 rounded-lg text-2xs font-semibold border border-border-subtle hover:bg-glass-1 transition-colors"
          >
            ← Back to Builder
          </button>
        </div>
        <PreviewPanel sessionId={simSession} />
      </div>
    );

  /* ═══ MAIN BUILDER ═══ */
  return (
    <div
      className="flex rounded-2xl border border-border-subtle bg-bg"
      style={{ height: 'calc(100vh - 180px)', minHeight: 500 }}
    >
      {/* ═══ LEFT — CANVAS AREA ═══ */}
      <div className="flex-1 flex flex-col min-w-0">
        {/* NLP Magic Bar — fixed at top, outside canvas scroll */}
        <div className="flex-shrink-0 px-4 pt-3 pb-1 relative z-20">
          <div className="max-w-[560px] mx-auto">
            <div
              className="rounded-2xl overflow-hidden bg-bg-shell border border-border-subtle"
              style={{ boxShadow: '0 8px 32px rgba(0,0,0,.4)' }}
            >
              <div className="flex items-center p-2 gap-2">
                <div
                  className="w-10 h-10 rounded-xl flex items-center justify-center text-lg flex-shrink-0"
                  style={{ background: 'linear-gradient(135deg,#047857,#059669)' }}
                >
                  ✨
                </div>
                <input
                  value={nlpInput}
                  onChange={(e) => setNlpInput(e.target.value)}
                  onKeyDown={(e) => e.key === 'Enter' && processNlp()}
                  placeholder="Describe your bot..."
                  disabled={generateFlow.isPending}
                  className="flex-1 bg-transparent border-none outline-none text-sm py-2.5 px-2 text-text-primary placeholder:text-text-muted"
                />
                <button
                  onClick={processNlp}
                  disabled={generateFlow.isPending || !nlpInput.trim()}
                  className="w-10 h-10 rounded-xl border-none text-white text-lg cursor-pointer flex-shrink-0 flex items-center justify-center disabled:opacity-40"
                  style={{ background: 'linear-gradient(135deg,#059669,#10B981)' }}
                >
                  {generateFlow.isPending ? <Loader2 className="w-5 h-5 animate-spin" /> : '→'}
                </button>
              </div>

              {/* Thinking animation */}
              {generateFlow.isPending && thinkStep >= 0 && (
                <div
                  className="px-4 pb-3 pt-2 border-t border-border-subtle"
                  style={{
                    background:
                      'linear-gradient(90deg,rgba(0,217,126,0.04),rgba(167,139,250,0.06),rgba(0,217,126,0.04))',
                    backgroundSize: '200% 100%',
                    animation: 'shimmer 2s linear infinite',
                  }}
                >
                  <div className="flex items-center gap-2 mb-2">
                    <span className="text-lg">🧠</span>
                    <span className="text-xs font-bold text-brand">AI designing...</span>
                  </div>
                  {STEPS.map((s, i) => (
                    <div
                      key={i}
                      className="flex items-center gap-1.5 text-xs mb-px"
                      style={{
                        color: i < thinkStep ? '#10B981' : i === thinkStep ? '#059669' : '#708A7E',
                        fontWeight: i === thinkStep ? 600 : 400,
                      }}
                    >
                      <span className="w-3 text-center">
                        {i < thinkStep ? '✓' : i === thinkStep ? '●' : '○'}
                      </span>
                      {s}
                    </div>
                  ))}
                </div>
              )}

              {/* Hints */}
              {!generateFlow.isPending && (
                <div className="px-4 pb-2.5 pt-1.5 border-t border-border-subtle bg-glass-1">
                  <div className="text-[11px] font-semibold text-text-muted mb-1.5">✨ Try:</div>
                  <div className="flex flex-wrap gap-1">
                    {HINTS.map((h) => (
                      <button
                        key={h}
                        onClick={() => setNlpInput(h)}
                        className="px-2.5 py-1 rounded-md text-2xs cursor-pointer bg-bg-shell border border-border-subtle text-text-secondary hover:border-brand hover:text-brand hover:bg-brand-soft transition-all"
                      >
                        {h}
                      </button>
                    ))}
                  </div>
                </div>
              )}
            </div>
          </div>
        </div>

        {/* Canvas — takes all remaining height */}
        <div className="flex-1 relative min-h-0">
          {/* Palette — overlaid on canvas */}
          <div
            className="absolute left-4 top-2 bg-bg-shell rounded-xl p-3 z-10 select-none"
            style={{ boxShadow: '0 4px 20px rgba(0,0,0,.4)', width: 140 }}
          >
            <h4 className="text-[11px] font-bold text-text-muted uppercase mb-2 tracking-wider">
              Drag to canvas
            </h4>
            {PAL.map((p) => (
              <div
                key={p.type}
                draggable
                onDragStart={(e) => {
                  e.dataTransfer.setData('application/reactflow-type', p.type);
                  e.dataTransfer.effectAllowed = 'move';
                }}
                onClick={() => editor.addNode(p.type, `New ${p.label}`)}
                className="flex items-center gap-2 px-2 py-[7px] rounded-lg text-2xs cursor-grab mb-px hover:bg-brand-soft hover:text-brand transition-colors text-text-secondary active:cursor-grabbing"
              >
                <span
                  className="w-5 h-5 rounded flex items-center justify-center text-[11px]"
                  style={{ background: p.bg }}
                >
                  {p.icon}
                </span>
                {p.label}
              </div>
            ))}
          </div>

          {/* React Flow — explicit 100% height */}
          <ReactFlow
            nodes={editor.nodes}
            edges={editor.edges}
            onNodesChange={editor.onNodesChange}
            onEdgesChange={editor.onEdgesChange}
            onConnect={editor.onConnect}
            onNodeClick={(_, n) => {
              setSel(n as Node<FlowNodeData>);
              setTab(1);
            }}
            onPaneClick={() => setSel(null)}
            onDragOver={onDragOver}
            onDrop={onDrop}
            nodeTypes={nodeTypes}
            fitView
            proOptions={{ hideAttribution: true }}
            defaultEdgeOptions={{
              type: 'smoothstep',
              animated: true,
              style: { stroke: '#059669', strokeWidth: 2 },
            }}
            style={{ width: '100%', height: '100%', background: '#0A0F0D' }}
          >
            <Background gap={20} size={1} color="#1E2E26" />
            <Controls
              position="bottom-right"
              showInteractive={false}
              className="!bg-bg-shell !border-border-subtle !rounded-lg !shadow-none text-black"
            />
            <MiniMap
              position="bottom-right"
              style={{ bottom: 80 }}
              nodeColor={(n) => NODE_TYPE_META[(n.data as FlowNodeData)?.nodeType]?.color || '#708A7E'}
              maskColor="rgba(10,15,13,0.7)"
              className="!bg-bg-shell !border-border-subtle !rounded-lg"
            />
          </ReactFlow>

          {/* Empty state */}
          {editor.nodes.length === 0 && (
            <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
              <div className="text-center">
                <div className="text-5xl mb-3 opacity-40">✨</div>
                <div className="text-base font-bold text-text-primary mb-1">Design Your Bot</div>
                <div className="text-xs text-text-muted">Describe it above, or drag blocks from the left</div>
              </div>
            </div>
          )}
        </div>

        {/* Toolbar — fixed at bottom */}
        <div className="flex items-center gap-2 px-4 py-2 border-t border-border-subtle bg-bg flex-shrink-0">
          <button
            onClick={() => setShowList(true)}
            className="p-1.5 rounded-md hover:bg-glass-1 text-text-muted"
            title="Saved flows"
          >
            <FolderOpen className="w-4 h-4" />
          </button>
          {editingName ? (
            <input
              autoFocus
              value={editor.flowName}
              onChange={(e) => editor.setFlowName(e.target.value)}
              onBlur={() => setEditingName(false)}
              onKeyDown={(e) => {
                if (e.key === 'Enter') setEditingName(false);
                if (e.key === 'Escape') setEditingName(false);
              }}
              className="text-xs font-semibold text-text-primary max-w-[180px] px-1.5 py-0.5 border border-brand rounded-md outline-none bg-bg-shell text-text-primary"
            />
          ) : (
            <button
              onClick={() => setEditingName(true)}
              className="flex items-center gap-1 text-xs font-semibold text-text-primary truncate max-w-[160px] hover:text-brand transition-colors"
              title="Click to rename"
            >
              {editor.flowName || 'Untitled Flow'}
              <Pencil className="w-3 h-3 text-text-muted flex-shrink-0" />
            </button>
          )}
          {editor.isDirty && (
            <span className="w-1.5 h-1.5 rounded-full bg-amber-400 flex-shrink-0" title="Unsaved" />
          )}
          {loadedFlow?.isActive && (
            <span className="px-1.5 py-0.5 rounded text-[10px] font-bold text-white bg-brand flex-shrink-0">
              LIVE
            </span>
          )}
          <div className="ml-auto flex items-center gap-1">
            <button
              onClick={editor.undo}
              disabled={!editor.canUndo}
              className="p-1.5 rounded-md hover:bg-glass-1 text-text-muted disabled:opacity-30"
              title="Undo"
            >
              <Undo2 className="w-3.5 h-3.5" />
            </button>
            <button
              onClick={editor.redo}
              disabled={!editor.canRedo}
              className="p-1.5 rounded-md hover:bg-glass-1 text-text-muted disabled:opacity-30"
              title="Redo"
            >
              <Redo2 className="w-3.5 h-3.5" />
            </button>
            <div className="w-px h-5 bg-border-subtle mx-1" />
            <button
              onClick={editor.manualSave}
              disabled={!editor.flowId || editor.isSaving}
              className="p-1.5 rounded-md hover:bg-glass-1 text-text-muted disabled:opacity-30"
              title="Save"
            >
              {editor.isSaving ? (
                <Loader2 className="w-3.5 h-3.5 animate-spin" />
              ) : (
                <Save className="w-3.5 h-3.5" />
              )}
            </button>
            <button
              onClick={() => editor.flowId && duplicateFlow.mutate(editor.flowId)}
              disabled={!editor.flowId}
              className="p-1.5 rounded-md hover:bg-glass-1 text-text-muted disabled:opacity-30"
              title="Duplicate"
            >
              <Copy className="w-3.5 h-3.5" />
            </button>
            <button
              onClick={editor.clear}
              className="p-1.5 rounded-md hover:bg-glass-1 text-danger"
              title="Clear"
            >
              <Trash2 className="w-3.5 h-3.5" />
            </button>
            <div className="w-px h-5 bg-border-subtle mx-1" />
            <button
              onClick={() => editor.flowId && activateFlow.mutate(editor.flowId)}
              disabled={!editor.flowId || activateFlow.isPending}
              className="px-3 py-1.5 rounded-lg text-2xs font-bold text-white border-none cursor-pointer disabled:opacity-40 flex items-center gap-1.5 hover:-translate-y-px transition-all"
              style={{ background: 'linear-gradient(135deg,#059669,#10B981)' }}
            >
              {activateFlow.isPending ? (
                <Loader2 className="w-3.5 h-3.5 animate-spin" />
              ) : (
                <Rocket className="w-3.5 h-3.5" />
              )}
              Deploy
            </button>
          </div>
        </div>
      </div>

      {/* ═══ RIGHT PANEL ═══ */}
      <div className="w-[280px] flex-shrink-0 flex flex-col border-l border-border-subtle bg-bg">
        {/* Header */}
        <div className="px-4 py-3 border-b border-border-subtle flex items-center justify-between flex-shrink-0">
          <div>
            <h3 className="text-xs font-bold text-text-primary">🤖 AI Assistant</h3>
            <p className="text-2xs text-text-muted mt-0.5">Chat to modify your bot</p>
          </div>
          <button
            onClick={() => setShowPreview(true)}
            className="px-2 py-1 rounded-md text-[10px] font-semibold text-brand border border-brand/30 hover:bg-brand-soft transition-colors"
          >
            📱 Preview
          </button>
        </div>

        {/* Tabs */}
        <div className="flex border-b border-border-subtle flex-shrink-0">
          {['AI Chat', 'Configure', 'Test'].map((t, i) => (
            <button
              key={t}
              onClick={() => setTab(i as 0 | 1 | 2)}
              className={`flex-1 py-2 text-center text-2xs font-semibold border-b-2 transition-colors ${tab === i ? 'text-brand border-brand' : 'text-text-muted border-transparent hover:text-text-secondary'}`}
            >
              {t}
            </button>
          ))}
        </div>

        {/* Tab content — scrollable */}
        <div className="flex-1 min-h-0 overflow-hidden flex flex-col">
          {/* ── TAB 0: AI Chat ── */}
          {tab === 0 && (
            <>
              {sel && (
                <div className="px-3 py-2.5 border-b border-border-subtle flex-shrink-0">
                  <div className="text-[11px] font-bold uppercase tracking-wider text-text-muted mb-1">
                    Selected
                  </div>
                  <input
                    value={(sel.data as FlowNodeData).label}
                    onChange={(e) => updateNodeData(sel.id, { label: e.target.value })}
                    className="w-full px-2 py-1 rounded-md bg-bg border border-border-subtle text-2xs text-text-primary outline-none focus:border-brand mb-1"
                  />
                  <div className="flex items-center gap-1">
                    <span
                      className="w-4 h-4 rounded flex items-center justify-center text-[11px]"
                      style={{ background: NODE_TYPE_META[(sel.data as FlowNodeData).nodeType]?.bg }}
                    >
                      {NODE_TYPE_META[(sel.data as FlowNodeData).nodeType]?.icon}
                    </span>
                    <span className="text-2xs text-text-muted">
                      {NODE_TYPE_META[(sel.data as FlowNodeData).nodeType]?.label}
                    </span>
                  </div>
                  <button
                    onClick={() => {
                      editor.removeNode(sel.id);
                      setSel(null);
                    }}
                    className="mt-1.5 w-full py-1 rounded-md bg-danger-soft border border-[rgba(244,63,94,.12)] text-2xs font-semibold text-danger cursor-pointer"
                  >
                    Delete
                  </button>
                </div>
              )}
              <div className="flex-1 overflow-y-auto px-3 py-2">
                {chatMsgs.map((m, i) => (
                  <div key={i} className={`mb-2 ${m.role === 'user' ? 'text-right' : ''}`}>
                    <div
                      className="inline-block max-w-[90%] px-3 py-2 text-2xs leading-relaxed whitespace-pre-wrap"
                      style={{
                        borderRadius: 10,
                        ...(m.role === 'user'
                          ? {
                              background: 'linear-gradient(135deg,#059669,#10B981)',
                              color: '#fff',
                              borderBottomRightRadius: 3,
                            }
                          : {
                              background: '#0D1410',
                              color: '#8A9B91',
                              border: '1px solid #1E2E26',
                              borderBottomLeftRadius: 3,
                            }),
                      }}
                    >
                      {m.text}
                    </div>
                  </div>
                ))}
                {chatModify.isPending && (
                  <div className="mb-2">
                    <div
                      className="inline-block px-3 py-2 text-2xs rounded-[10px]"
                      style={{
                        background:
                          'linear-gradient(90deg,rgba(0,217,126,0.04),rgba(167,139,250,0.06),rgba(0,217,126,0.04))',
                        backgroundSize: '200% 100%',
                        animation: 'shimmer 2s linear infinite',
                      }}
                    >
                      <span className="text-xs">🧠</span>{' '}
                      <span className="text-brand font-semibold">Modifying...</span>
                    </div>
                  </div>
                )}
                <div ref={chatEndRef} />
              </div>
              <div className="flex gap-1.5 p-2.5 border-t border-border-subtle flex-shrink-0">
                <input
                  value={chatInput}
                  onChange={(e) => setChatInput(e.target.value)}
                  onKeyDown={(e) => e.key === 'Enter' && sendChat()}
                  placeholder={editor.flowId ? 'Ask AI...' : 'Generate a flow first'}
                  disabled={!editor.flowId || chatModify.isPending}
                  className="flex-1 px-2.5 py-2 rounded-lg bg-glass-1 border border-border-subtle text-2xs text-text-primary outline-none focus:border-brand disabled:opacity-50"
                />
                <button
                  onClick={sendChat}
                  disabled={!editor.flowId || !chatInput.trim() || chatModify.isPending}
                  className="px-3 py-2 rounded-lg text-2xs font-semibold text-white border-none cursor-pointer disabled:opacity-40"
                  style={{ background: '#059669' }}
                >
                  <Send className="w-3 h-3" />
                </button>
              </div>
            </>
          )}

          {/* ── TAB 1: Configure ── */}
          {tab === 1 && (
            <div className="flex-1 overflow-y-auto p-4">
              {sel ? (
                <div className="space-y-3">
                  <div>
                    <label className="block text-2xs font-semibold mb-1">Name</label>
                    <input
                      value={(sel.data as FlowNodeData).label}
                      onChange={(e) => updateNodeData(sel.id, { label: e.target.value })}
                      className="w-full px-2.5 py-1.5 border border-border-subtle rounded-lg text-xs outline-none focus:border-brand placeholder:text-text-muted bg-bg-shell"
                    />
                  </div>
                  <div>
                    <label className="block text-2xs font-semibold mb-1">Type</label>
                    <input
                      value={
                        NODE_TYPE_META[(sel.data as FlowNodeData).nodeType]?.label ||
                        (sel.data as FlowNodeData).nodeType
                      }
                      disabled
                      className="w-full px-2.5 py-1.5 border border-border-subtle rounded-lg text-xs bg-glass-1 text-text-muted"
                    />
                  </div>
                  <div>
                    <label className="block text-2xs font-semibold mb-1">Configuration JSON</label>
                    <textarea
                      value={JSON.stringify((sel.data as FlowNodeData).config || {}, null, 2)}
                      onChange={(e) => {
                        try {
                          updateNodeData(sel.id, { config: JSON.parse(e.target.value) });
                        } catch {}
                      }}
                      rows={5}
                      className="w-full px-2.5 py-1.5 border border-border-subtle rounded-lg text-[10px] font-mono outline-none focus:border-brand resize-none placeholder:text-text-muted bg-bg-shell"
                    />
                  </div>
                  <button
                    onClick={() => {
                      editor.removeNode(sel.id);
                      setSel(null);
                    }}
                    className="w-full py-2 rounded-lg bg-danger-soft text-2xs font-semibold text-danger flex items-center justify-center gap-1.5"
                  >
                    <Trash2 className="w-3 h-3" />
                    Delete Node
                  </button>
                </div>
              ) : (
                <p className="text-xs text-text-muted text-center py-8">Select a node on the canvas</p>
              )}
            </div>
          )}

          {/* ── TAB 2: Simulator ── */}
          {tab === 2 && <FlowSimulator />}
        </div>
      </div>

      {/* Flow List Overlay */}
      {showList && (
        <FlowListOverlay
          flows={flows}
          onSelect={(f) => {
            editor.setFlow(f);
            setSel(null);
            setShowList(false);
          }}
          onClose={() => setShowList(false)}
          onDelete={(id) => deleteFlow.mutate(id)}
          onDuplicate={(id) => duplicateFlow.mutate(id)}
        />
      )}
    </div>
  );
}

/* ═══ FLOW LIST DIALOG ═══ */
function FlowListOverlay({
  flows,
  onSelect,
  onClose,
  onDelete,
  onDuplicate,
}: {
  flows: FlowDto[];
  onSelect: (f: FlowDto) => void;
  onClose: () => void;
  onDelete: (id: string) => void;
  onDuplicate: (id: string) => void;
}) {
  return (
    <div
      className="fixed inset-0 z-[100] flex items-center justify-center bg-black/60 backdrop-blur-sm"
      onClick={onClose}
    >
      <div
        className="bg-bg-shell rounded-2xl w-[480px] max-h-[70vh] flex flex-col shadow-[0_24px_64px_rgba(0,0,0,0.5)] border border-border-subtle"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="flex items-center justify-between px-5 py-4 border-b border-border-subtle flex-shrink-0">
          <h3 className="text-sm font-bold text-text-primary">Saved Flows</h3>
          <button onClick={onClose} className="p-1 rounded-md hover:bg-glass-1">
            <X className="w-4 h-4 text-text-muted" />
          </button>
        </div>
        <div className="flex-1 overflow-y-auto p-3">
          {flows.length === 0 ? (
            <div className="text-center py-12">
              <div className="text-3xl mb-2 opacity-40">📋</div>
              <p className="text-xs text-text-muted">No flows yet.</p>
            </div>
          ) : (
            <div className="space-y-1.5">
              {flows.map((f) => (
                <div
                  key={f.id}
                  onClick={() => onSelect(f)}
                  className="flex items-center gap-3 p-3 rounded-xl border border-border-subtle hover:border-brand hover:bg-brand-soft/30 transition-all cursor-pointer group"
                >
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2">
                      <span className="text-xs font-semibold text-text-primary truncate">{f.name}</span>
                      {f.isActive && (
                        <span className="flex items-center gap-0.5 px-1.5 py-0.5 rounded text-[10px] font-bold text-white bg-brand">
                          <Check className="w-2.5 h-2.5" /> Live
                        </span>
                      )}
                    </div>
                    <div className="text-[10px] text-text-muted mt-0.5">
                      v{f.version} • {f.nodeCount} nodes • {FLOW_STATUS_LABEL[f.status] || 'Draft'}
                    </div>
                  </div>
                  <div className="flex items-center gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        onDuplicate(f.id);
                      }}
                      className="p-1.5 rounded-md hover:bg-glass-1"
                    >
                      <Copy className="w-3 h-3 text-text-muted" />
                    </button>
                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        if (confirm(`Delete "${f.name}"?`)) onDelete(f.id);
                      }}
                      disabled={f.isActive}
                      className="p-1.5 rounded-md hover:bg-danger-soft disabled:opacity-30"
                    >
                      <Trash2 className="w-3 h-3 text-danger" />
                    </button>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

/* ═══ MULTI-CHANNEL PREVIEW ═══ */
function PreviewPanel({ sessionId }: { sessionId: string }) {
  const [input, setInput] = useState('');
  type Msg = { role: 'user' | 'bot'; text: string; buttons?: { label: string; value: string }[] };
  const [msgs, setMsgs] = useState<Record<string, Msg[]>>({});
  const flowMessage = useFlowRuntimeMessage();
  const { data: channelsRaw } = useChannels();
  const channels = useMemo(() => {
    const list = (channelsRaw as unknown as ChannelConnectionDto[]) ?? [];
    const connected = list.filter((c) => !c.isDeleted);
    if (connected.length > 0) {
      return connected.map((c) => ({
        key: CHANNEL_TYPE_LABEL[c.channelType] || `Channel ${c.channelType}`,
        apiType: (CHANNEL_TYPE_LABEL[c.channelType] || '').toLowerCase().replace(/\s+/g, ''),
        displayName: c.displayName || CHANNEL_TYPE_LABEL[c.channelType] || `Channel ${c.channelType}`,
      }));
    }
    return [
      { key: 'WhatsApp', apiType: 'whatsapp', displayName: 'WhatsApp' },
      { key: 'WebChat', apiType: 'webchat', displayName: 'Web Chat' },
    ];
  }, [channelsRaw]);

  const [selectedChannels, setSelectedChannels] = useState<string[]>([]);
  useEffect(() => {
    if (selectedChannels.length === 0 && channels.length > 0) {
      setSelectedChannels(channels.map((c) => c.key));
    }
  }, [channels]); // eslint-disable-line react-hooks/exhaustive-deps

  const activeChannels = useMemo(
    () => channels.filter((c) => selectedChannels.includes(c.key)),
    [channels, selectedChannels],
  );
  const gridCols =
    activeChannels.length <= 2 ? 'grid-cols-2' : activeChannels.length === 3 ? 'grid-cols-3' : 'grid-cols-4';

  const send = useCallback(
    (text: string) => {
      if (!text.trim() || flowMessage.isPending) return;
      setMsgs((p) => {
        const n = { ...p };
        activeChannels.forEach((c) => (n[c.key] = [...(n[c.key] || []), { role: 'user', text }]));
        return n;
      });
      setInput('');
      // Single flow-runtime call — menuItems included in response
      flowMessage.mutate(
        { SessionId: sessionId, Message: text.trim() },
        {
          onSuccess: (res: FlowRuntimeResult) => {
            const buttons = (res.menuItems || []).map((it: FlowMenuItemDto) => ({
              label: it.label,
              value: it.value,
            }));
            activeChannels.forEach((ch) => {
              setMsgs((p) => ({
                ...p,
                [ch.key]: [
                  ...(p[ch.key] || []),
                  {
                    role: 'bot',
                    text: res.response || '-',
                    buttons: buttons.length > 0 ? buttons : undefined,
                  },
                ],
              }));
            });
          },
          onError: () =>
            activeChannels.forEach((ch) =>
              setMsgs((p) => ({ ...p, [ch.key]: [...(p[ch.key] || []), { role: 'bot', text: '❌ Error' }] })),
            ),
        },
      );
    },
    [flowMessage, sessionId, activeChannels],
  );

  // Channel-specific colors with fallback
  const getStyle = (name: string) => {
    const n = name.toLowerCase();
    if (n.includes('whatsapp'))
      return { hdr: '#075E54', bg: '#ECE5DD', userBg: '#DCF8C6', botBg: '#fff', dark: false };
    if (n.includes('telegram'))
      return { hdr: '#517DA2', bg: '#0E1621', userBg: '#2B5278', botBg: '#182533', dark: true };
    if (n.includes('web') || n.includes('chat'))
      return { hdr: '#059669', bg: '#0A0F0D', userBg: '#059669', botBg: '#0D1410', dark: true };
    if (n.includes('sms'))
      return { hdr: '#1E2E26', bg: '#0A0F0D', userBg: '#007AFF', botBg: '#0D1410', dark: true };
    if (n.includes('messenger'))
      return { hdr: '#0084FF', bg: '#0A0F0D', userBg: '#0084FF', botBg: '#0D1410', dark: true };
    if (n.includes('instagram'))
      return { hdr: '#E1306C', bg: '#0A0F0D', userBg: '#E1306C', botBg: '#0D1410', dark: true };
    if (n.includes('email'))
      return { hdr: '#4A90D9', bg: '#0A0F0D', userBg: '#4A90D9', botBg: '#0D1410', dark: true };
    if (n.includes('voice'))
      return { hdr: '#6B7280', bg: '#0A0F0D', userBg: '#4B5563', botBg: '#0D1410', dark: true };
    return { hdr: '#374151', bg: '#0A0F0D', userBg: '#6B7280', botBg: '#0D1410', dark: true };
  };

  return (
    <div className="flex flex-col flex-1 min-h-0">
      {/* Channel selector */}
      <div className="flex items-center gap-2 px-4 py-2 border-b border-border-subtle bg-glass-1 flex-shrink-0 flex-wrap">
        <span className="text-[10px] font-bold text-text-muted uppercase tracking-wider">Channels:</span>
        {channels.map((ch) => (
          <button
            key={ch.key}
            onClick={() =>
              setSelectedChannels((prev) =>
                prev.includes(ch.key) ? prev.filter((k) => k !== ch.key) : [...prev, ch.key],
              )
            }
            className={`px-2.5 py-1 rounded-md text-[10px] font-semibold transition-all ${
              selectedChannels.includes(ch.key)
                ? 'bg-brand text-white'
                : 'bg-bg-shell border border-border-subtle text-text-muted hover:border-brand hover:text-brand'
            }`}
          >
            {ch.displayName}
          </button>
        ))}
      </div>

      {/* Channel previews grid */}
      <div className={`flex-1 grid ${gridCols} gap-2 p-3 overflow-hidden min-h-0`}>
        {activeChannels.map((ch) => {
          const s = getStyle(ch.key);
          return (
            <div
              key={ch.key}
              className="flex flex-col rounded-xl overflow-hidden border border-border-subtle min-h-0"
            >
              <div
                className="text-center text-[10px] font-bold uppercase tracking-wider py-1.5 text-white flex-shrink-0"
                style={{ background: s.hdr }}
              >
                {ch.displayName}
              </div>
              <div className="flex-1 overflow-y-auto p-2 space-y-1" style={{ background: s.bg }}>
                {(msgs[ch.key] || []).length === 0 && (
                  <div className="text-center py-4 text-[10px] opacity-50">Send a message</div>
                )}
                {(msgs[ch.key] || []).map((m, i) => (
                  <div key={i} className={`flex ${m.role === 'user' ? 'justify-end' : 'justify-start'}`}>
                    <div className="max-w-[92%]">
                      <div
                        className="px-2 py-1.5 text-[10px] leading-relaxed whitespace-pre-wrap rounded-lg"
                        style={{
                          background: m.role === 'user' ? s.userBg : s.botBg,
                          color: s.dark || m.role === 'user' ? '#fff' : '#333',
                        }}
                      >
                        {m.text}
                      </div>
                      {m.buttons && m.buttons.length > 0 && (
                        <div className="mt-0.5 space-y-0.5">
                          {m.buttons.slice(0, 3).map((b, j) => (
                            <button
                              key={j}
                              onClick={() => send(b.value)}
                              className="w-full py-1 rounded text-[9px] font-medium bg-bg-shell/90 border border-border-subtle hover:bg-glass-1 text-center truncate text-text-secondary"
                            >
                              {b.label}
                            </button>
                          ))}
                        </div>
                      )}
                    </div>
                  </div>
                ))}
              </div>
            </div>
          );
        })}
        {activeChannels.length === 0 && (
          <div className="col-span-full flex items-center justify-center py-12 text-sm text-text-muted">
            Select at least one channel above to preview
          </div>
        )}
      </div>

      {/* Input */}
      <div className="flex gap-2 px-4 py-3 border-t border-border-subtle bg-bg flex-shrink-0">
        <input
          value={input}
          onChange={(e) => setInput(e.target.value)}
          onKeyDown={(e) => e.key === 'Enter' && send(input)}
          placeholder={`Type (sends to ${activeChannels.length} channel${activeChannels.length !== 1 ? 's' : ''})...`}
          className="flex-1 px-3 py-2 border border-border-subtle rounded-lg text-sm outline-none focus:border-brand bg-bg-shell text-text-primary placeholder:text-text-muted"
        />
        <button
          onClick={() => send(input)}
          disabled={!input.trim() || flowMessage.isPending || activeChannels.length === 0}
          className="px-4 py-2 rounded-lg text-sm font-semibold text-white disabled:opacity-40 flex items-center gap-1.5"
          style={{ background: 'linear-gradient(135deg,#059669,#10B981)' }}
        >
          {flowMessage.isPending ? (
            <Loader2 className="w-4 h-4 animate-spin" />
          ) : (
            <Send className="w-4 h-4" />
          )}
          Send
        </button>
      </div>
    </div>
  );
}

/* ═══ EXPORT ═══ */
export function Component() {
  return (
    <ReactFlowProvider>
      <FlowBuilderInner />
    </ReactFlowProvider>
  );
}
